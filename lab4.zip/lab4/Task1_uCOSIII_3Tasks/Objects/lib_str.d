./objects/lib_str.o: Middlewares\Third_Party\uCOS-III\LIB\lib_str.c \
  Middlewares\Third_Party\uCOS-III\LIB\lib_str.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu_def.h App\Inc\cpu_cfg.h \
  Middlewares\Third_Party\uCOS-III\LIB\lib_def.h \
  Middlewares\Third_Party\uCOS-III\LIB\lib_ascii.h App\Inc\lib_cfg.h
