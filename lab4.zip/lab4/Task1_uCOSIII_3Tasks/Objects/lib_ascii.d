./objects/lib_ascii.o: Middlewares\Third_Party\uCOS-III\LIB\lib_ascii.c \
  Middlewares\Third_Party\uCOS-III\LIB\lib_ascii.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu_def.h App\Inc\cpu_cfg.h \
  Middlewares\Third_Party\uCOS-III\LIB\lib_def.h
