./objects/cpu_c.o: Middlewares\Third_Party\uCOS-III\CPU\cpu_c.c \
  Middlewares\Third_Party\uCOS-III\CPU\cpu.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu_def.h App\Inc\cpu_cfg.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu_core.h \
  Middlewares\Third_Party\uCOS-III\LIB\lib_def.h
