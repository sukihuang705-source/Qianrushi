./objects/os_cpu_c.o: Middlewares\Third_Party\uCOS-III\Ports\os_cpu_c.c \
  Middlewares\Third_Party\uCOS-III\Ports\..\Source\os.h App\Inc\os_cfg.h \
  App\Inc\os_cfg_app.h Middlewares\Third_Party\uCOS-III\CPU\cpu_core.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu_def.h App\Inc\cpu_cfg.h \
  Middlewares\Third_Party\uCOS-III\LIB\lib_def.h \
  Middlewares\Third_Party\uCOS-III\Ports\..\Source\os_type.h \
  Middlewares\Third_Party\uCOS-III\Ports\os_cpu.h \
  Middlewares\Third_Party\uCOS-III\Ports\..\Source\os_trace.h
