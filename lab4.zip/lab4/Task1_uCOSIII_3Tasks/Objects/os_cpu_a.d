./objects/os_cpu_a.o: Middlewares\Third_Party\uCOS-III\Ports\os_cpu_a.S
