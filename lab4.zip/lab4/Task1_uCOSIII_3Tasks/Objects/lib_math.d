./objects/lib_math.o: Middlewares\Third_Party\uCOS-III\LIB\lib_math.c \
  Middlewares\Third_Party\uCOS-III\LIB\lib_math.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu_def.h App\Inc\cpu_cfg.h \
  Middlewares\Third_Party\uCOS-III\CPU\cpu_core.h \
  Middlewares\Third_Party\uCOS-III\LIB\lib_def.h
