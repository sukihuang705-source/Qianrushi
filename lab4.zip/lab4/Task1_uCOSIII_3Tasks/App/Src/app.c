﻿/**
  ******************************************************************************
  * @file    app.c
  * @brief   三个任务的具体实现
  ******************************************************************************
  */

#include "app.h"
#include "bsp_led.h"
#include "bsp_usart.h"

/* ---------------- 任务控制块 ---------------- */
OS_TCB  AppTask1TCB;
OS_TCB  AppTask2TCB;
OS_TCB  AppTask3TCB;

/* ---------------- 任务栈 ---------------- */
CPU_STK AppTask1Stk[APP_TASK1_STK_SIZE];
CPU_STK AppTask2Stk[APP_TASK2_STK_SIZE];
CPU_STK AppTask3Stk[APP_TASK3_STK_SIZE];

/* 任务3 要发送的内容(源文件为 UTF-8 编码，串口助手也请选 UTF-8) */
static const char APP_MSG[] = "hello uc/OS! 欢迎来到RTOS多任务环境！\r\n";


/**
  * @brief  任务1：每 1s 翻转一次 LED1（亮 1s、灭 1s）
  * @note   用 OS_OPT_TIME_PERIODIC 让延时"按周期"计算，不会因为任务执行时间
  *         和调度延迟而累积误差(这就是 RTOS 周期任务的常用写法)
  */
void AppTask1(void *p_arg)
{
    OS_ERR err;

    (void)p_arg;

    while (1)
    {
        BSP_LED1_Toggle();
        OSTimeDly(APP_TASK1_TOGGLE_MS, OS_OPT_TIME_PERIODIC, &err);
    }
}


/**
  * @brief  任务2：每 3s 翻转一次 LED2（亮 3s、灭 3s）
  */
void AppTask2(void *p_arg)
{
    OS_ERR err;

    (void)p_arg;

    while (1)
    {
        BSP_LED2_Toggle();
        OSTimeDly(APP_TASK2_TOGGLE_MS, OS_OPT_TIME_PERIODIC, &err);
    }
}


/**
  * @brief  任务3：每 2s 通过串口1 发送一句问候
  */
void AppTask3(void *p_arg)
{
    OS_ERR err;

    (void)p_arg;

    while (1)
    {
        uart_send_string(APP_MSG);
        OSTimeDly(APP_TASK3_PERIOD_MS, OS_OPT_TIME_PERIODIC, &err);
    }
}
