/**
  ******************************************************************************
  * @file    app.h
  * @brief   应用层：三个任务的优先级、栈大小、周期和任务函数声明
  ******************************************************************************
  */

#ifndef __APP_H
#define __APP_H

#include "os.h"

/* ---------------- 任务优先级：数值越小优先级越高 ---------------- */
#define APP_TASK1_PRIO          5u
#define APP_TASK2_PRIO          6u
#define APP_TASK3_PRIO          7u

/* ---------------- 任务栈大小(单位：OS_STK，1 个 = 4 字节) ---------------- */
#define APP_TASK1_STK_SIZE      256u     /* 1KB */
#define APP_TASK2_STK_SIZE      256u     /* 1KB */
#define APP_TASK3_STK_SIZE      512u     /* 2KB，串口打印用得多一点 */

/* ---------------- 周期(节拍频率 1000Hz，所以 1ms = 1 个 tick) ----------------
 * 题目要求"以 1s 和 3s 周期对 LED 进行点亮-熄灭"：
 *   LED1 亮 1s、灭 1s(即每 1s 翻转一次)；LED2 亮 3s、灭 3s(每 3s 翻转一次)。
 * 如果你要的是"完整亮灭周期 1s/3s"(即每 0.5s / 1.5s 翻转)，把下面两个值改成 500 / 1500。
 */
#define APP_TASK1_TOGGLE_MS     1000u    /* LED1 翻转间隔：1s */
#define APP_TASK2_TOGGLE_MS     3000u    /* LED2 翻转间隔：3s */
#define APP_TASK3_PERIOD_MS     2000u    /* 串口发送周期：2s */

/* ---------------- 任务控制块 / 任务栈 / 任务函数 ---------------- */
extern OS_TCB  AppTask1TCB;
extern OS_TCB  AppTask2TCB;
extern OS_TCB  AppTask3TCB;

extern CPU_STK AppTask1Stk[APP_TASK1_STK_SIZE];
extern CPU_STK AppTask2Stk[APP_TASK2_STK_SIZE];
extern CPU_STK AppTask3Stk[APP_TASK3_STK_SIZE];

void AppTask1(void *p_arg);
void AppTask2(void *p_arg);
void AppTask3(void *p_arg);

#endif /* __APP_H */
