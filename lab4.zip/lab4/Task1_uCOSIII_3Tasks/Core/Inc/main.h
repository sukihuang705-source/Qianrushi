﻿/**
  ******************************************************************************
  * @file    main.h
  * @brief   工程公共头文件：芯片型号宏、HAL 库头文件、公共函数声明
  *
  * 注意：HAL 库的芯片型号宏和标准外设库不一样——
  *       C8T6(中等容量)在 HAL 里是 STM32F103xB，不是 STM32F10X_MD。
  ******************************************************************************
  */

#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* 芯片型号：STM32F103C8T6 → STM32F103xB(中等容量)。
   注意：HAL 库的型号宏和标准库不一样(不是 STM32F10X_MD)。
   此宏在 Keil 工程 Define 栏里也定义了，这里用 ifndef 避免重复定义警告 */
#ifndef STM32F103xB
#define STM32F103xB
#endif

/* 包含 HAL 库总头文件(它会根据上面型号宏包含对应的器件头) */
#include "stm32f1xx_hal.h"

/* 致命错误处理：关中断后原地死循环，方便用调试器查看调用栈 */
void Error_Handler(void);

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
