﻿/****************************************************************************
 * 文件名 : stm32f1xx_hal_timebase_tim.c
 * 实验   : 嵌入式实验四  任务一  uC/OS-III
 * 功能   : 把 HAL 库的 1ms 时基从 SysTick 换成 TIM4。
 *
 * 【为什么要换】
 *   HAL 默认用 SysTick 产生 1ms 中断给 HAL_IncTick() 计时；
 *   而 uC/OS-III 的移植层必须独占 SysTick 来产生系统节拍(OSTimeTick)。
 *   两者抢同一个定时器，只能二选一：SysTick 归 uC/OS-III，
 *   HAL 的节拍改用 TIM4(1ms 中断一次，里面照样调 HAL_IncTick())。
 *
 * 本文件是 HAL 库自带的 stm32f1xx_hal_timebase_tim_template.c 修改而来：
 *   模板用的是 TIM2，这里改成 TIM4，避免和呼吸灯/别的例程抢 TIM2。
 *   启用方法：把本文件加入工程即可(HAL_InitTick 是 __weak 的，会被这里的强符号覆盖)。
 ****************************************************************************/

#include "main.h"

TIM_HandleTypeDef htim4;   /* HAL 时基定时器句柄 */

/**
  * @brief  用 TIM4 配置 1ms 时基，HAL_Init() 里会自动调用
  * @param  TickPriority: TIM4 中断优先级
  * @retval HAL_OK / HAL_ERROR
  */
HAL_StatusTypeDef HAL_InitTick(uint32_t TickPriority)
{
    RCC_ClkInitTypeDef clkconfig;
    uint32_t           uwTimclock;
    uint32_t           uwAPB1Prescaler;
    uint32_t           uwPrescalerValue;
    uint32_t           pFLatency;
    HAL_StatusTypeDef  status;

    /* 打开 TIM4 时钟 */
    __HAL_RCC_TIM4_CLK_ENABLE();

    /* 取当前时钟树，算出 TIM4 的实际输入时钟 */
    HAL_RCC_GetClockConfig(&clkconfig, &pFLatency);
    uwAPB1Prescaler = clkconfig.APB1CLKDivider;
    if (uwAPB1Prescaler == RCC_HCLK_DIV1)
    {
        uwTimclock = HAL_RCC_GetPCLK1Freq();
    }
    else
    {
        uwTimclock = 2UL * HAL_RCC_GetPCLK1Freq();   /* APB1 分频后定时器时钟 x2 */
    }

    /* 预分频到 1MHz，则计数器 +1 = 1us；自动重装载 1000-1 → 每 1ms 中断一次 */
    uwPrescalerValue = (uint32_t)((uwTimclock / 1000000U) - 1U);

    htim4.Instance               = TIM4;
    htim4.Init.Period            = (1000000U / 1000U) - 1U;   /* 999 */
    htim4.Init.Prescaler         = uwPrescalerValue;
    htim4.Init.ClockDivision     = 0;
    htim4.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    status = HAL_TIM_Base_Init(&htim4);
    if (status == HAL_OK)
    {
        status = HAL_TIM_Base_Start_IT(&htim4);
        if (status == HAL_OK)
        {
            /* 中断优先级用 HAL 给的 TICK_INT_PRIORITY(默认 15，最低)，
               这样它不会打断 uC/OS-III 的内核临界区 */
            HAL_NVIC_SetPriority(TIM4_IRQn, TickPriority, 0U);
            uwTickPrio = TickPriority;
        }
        else
        {
            return HAL_ERROR;
        }
    }

    return status;
}

/**
  * @brief  TIM4 的中断服务函数(名字必须和启动文件里的一致)
  */
void TIM4_IRQHandler(void)
{
    HAL_TIM_IRQHandler(&htim4);
}


/**
  * @brief  定时器更新(溢出)中断回调：给 HAL 加 1ms
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM4)
    {
        HAL_IncTick();
    }
}


/**
  * @brief  挂起 HAL 时基(uC/OS-III 里一般用不到，HAL 模板要求实现)
  */
void HAL_SuspendTick(void)
{
    __HAL_TIM_DISABLE_IT(&htim4, TIM_IT_UPDATE);
}


/**
  * @brief  恢复 HAL 时基
  */
void HAL_ResumeTick(void)
{
    __HAL_TIM_ENABLE_IT(&htim4, TIM_IT_UPDATE);
}
