﻿/****************************************************************************
 * 文件名 : stm32f1xx_it.c
 * 实验   : 嵌入式实验四  任务一  uC/OS-III
 * 功能   : 中断服务函数。
 *
 * 【移植要点】uC/OS-III 在 Cortex-M3 上要用到两个异常：
 *   PendSV  —— 任务切换(OSCtxSw / OSIntCtxSw 都触发 PendSV)
 *   SysTick —— 系统节拍(每 1ms 一次，驱动延时和调度)
 * 所以本文件里这两个异常不能再留空，也不能再调 HAL_IncTick()，
 * 必须原样交给 uC/OS-III 移植层(os_cpu_a.S / os_cpu_c.c)处理。
 *
 * HAL 的 1ms 时基已经改用 TIM4 了(见 stm32f1xx_hal_timebase_tim.c)，
 * 因此 HAL_Delay()/HAL_GetTick() 仍然可以正常使用。
 ****************************************************************************/

#include "main.h"
#include "os.h"

/* ---------------- 内核异常 ---------------- */

void NMI_Handler(void)
{
    while (1) {}
}

void HardFault_Handler(void)
{
    while (1) {}
}

void MemManage_Handler(void)
{
    while (1) {}
}

void BusFault_Handler(void)
{
    while (1) {}
}

void UsageFault_Handler(void)
{
    while (1) {}
}

void SVC_Handler(void)
{
    /* 本移植用 PendSV 做任务切换，不使用 SVC */
}

void DebugMon_Handler(void)
{
}

/* ---------------- 交给 uC/OS-III 的两个异常 ---------------- */

/* 任务切换：OSCtxSw()/OSIntCtxSw() 里手动置位 PendSV，硬件随后进入这里 */
void PendSV_Handler(void)
{
    OS_CPU_PendSVHandler();
}

/* 系统节拍：每 1ms 进入一次，里面调用 OSTimeTick() 和 OSIntExit() */
void SysTick_Handler(void)
{
    OS_CPU_SysTickHandler();
}
