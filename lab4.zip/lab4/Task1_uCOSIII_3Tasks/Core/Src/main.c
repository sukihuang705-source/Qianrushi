﻿/****************************************************************************
 * 文件名 : main.c
 * 实验   : 嵌入式实验四  任务一  uC/OS-III 移植 + 三个任务
 * 功能   : 把 uC/OS-III 移植到 STM32F103C8T6 上，建立 3 个任务：
 *            Task1 每 500ms 翻转 LED1(PC13,板载,低电平点亮) → 完整亮灭周期 1s
 *            Task2 每 1500ms 翻转 LED2(PB12,外接,高电平点亮) → 完整亮灭周期 3s
 *            Task3 每 2s 通过 USART1 发送 "hello uc/OS! 欢迎来到RTOS多任务环境！"
 * 时钟   : 内部 HSI 8MHz(真机、软件仿真都能跑)
 * 时基   : HAL 时基用 TIM4(见 stm32f1xx_hal_timebase_tim.c)，
 *          SysTick 让给 uC/OS-III 做系统节拍(1000Hz)。
 ****************************************************************************/

#include "main.h"
#include "bsp_led.h"
#include "bsp_usart.h"
#include "app.h"

#include "os.h"
#include "cpu.h"

static void SystemClock_Config(void);


/****************************************************************************
 * 系统时钟 8MHz(内部 HSI，无 PLL)
 ****************************************************************************/
static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_OFF;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                       RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
    {
        Error_Handler();
    }
}


/****************************************************************************
 * 主函数
 * 顺序很重要：
 *   HAL_Init()            HAL 库初始化，并把 HAL 时基换成 TIM4
 *   SystemClock_Config()  系统时钟
 *   BSP_xxx_Init()        板级外设(先准备好 LED / 串口，任务一跑就能用)
 *   CPU_Init()            uC/OS-III 的 CPU 底层初始化
 *   OSInit()              内核初始化(就绪表、空闲任务、节拍等)
 *   OSTaskCreate()×3      创建 3 个任务
 *   OS_CPU_SysTickInit()  启动 SysTick 作为 RTOS 节拍
 *   OSStart()             启动调度器，此后 main 不再返回
 ****************************************************************************/
int main(void)
{
    OS_ERR err;

    HAL_Init();
    SystemClock_Config();

    BSP_LED_Init();            /* LED1=PC13(板载,低电平点亮) LED2=PB12(外接,高电平点亮) */
    BSP_USART1_Init(115200);   /* USART1: PA9(TX)/PA10(RX)，115200 8N1 */

    CPU_Init();
    OSInit(&err);
    if (err != OS_ERR_NONE)
    {
        Error_Handler();
    }

    /* ---- 任务1：1s 周期控制 LED1 ---- */
    OSTaskCreate(&AppTask1TCB,
                 "Task1 LED1 1s",
                 AppTask1,
                 (void *)0,
                 APP_TASK1_PRIO,
                 AppTask1Stk,
                 APP_TASK1_STK_SIZE / 10u,      /* 栈使用上限(警戒线) */
                 APP_TASK1_STK_SIZE,            /* 栈大小 */
                 0u,                            /* 不使用任务消息队列 */
                 0u,                            /* 时间片(不用轮转) */
                 (void *)0,
                 OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR,
                 &err);
    if (err != OS_ERR_NONE)
    {
        Error_Handler();
    }

    /* ---- 任务2：3s 周期控制 LED2 ---- */
    OSTaskCreate(&AppTask2TCB,
                 "Task2 LED2 3s",
                 AppTask2,
                 (void *)0,
                 APP_TASK2_PRIO,
                 AppTask2Stk,
                 APP_TASK2_STK_SIZE / 10u,
                 APP_TASK2_STK_SIZE,
                 0u,
                 0u,
                 (void *)0,
                 OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR,
                 &err);
    if (err != OS_ERR_NONE)
    {
        Error_Handler();
    }

    /* ---- 任务3：2s 周期串口发送 ---- */
    OSTaskCreate(&AppTask3TCB,
                 "Task3 UART 2s",
                 AppTask3,
                 (void *)0,
                 APP_TASK3_PRIO,
                 AppTask3Stk,
                 APP_TASK3_STK_SIZE / 10u,
                 APP_TASK3_STK_SIZE,
                 0u,
                 0u,
                 (void *)0,
                 OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR,
                 &err);
    if (err != OS_ERR_NONE)
    {
        Error_Handler();
    }

    /* ---- 启动 RTOS 节拍：SystemCoreClock / 节拍频率 = 每次节拍的计数值 ---- */
    OS_CPU_SysTickInit(SystemCoreClock / OS_CFG_TICK_RATE_HZ);

    /* ---- 启动调度器，开始多任务运行(不返回) ---- */
    OSStart(&err);
    if (err != OS_ERR_NONE)
    {
        Error_Handler();
    }

    while (1)
    {
    }
}


/****************************************************************************
 * 致命错误处理
 ****************************************************************************/
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
    }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
    while (1)
    {
    }
}
#endif
