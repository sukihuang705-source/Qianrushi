﻿/**
  ******************************************************************************
  * @file    bsp_led.h
  * @brief   LED 板级驱动：LED1 = PC13(板载，低电平点亮)
  *                      LED2 = PB12(外接，高电平点亮)
  ******************************************************************************
  */

#ifndef __BSP_LED_H
#define __BSP_LED_H

#include "main.h"

/* ---- LED1：开发板板载 LED，接 PC13，低电平点亮 ---- */
#define LED1_PORT        GPIOC
#define LED1_PIN         GPIO_PIN_13
#define LED1_ON_LEVEL    GPIO_PIN_RESET    /* 亮 = 输出低电平 */
#define LED1_OFF_LEVEL   GPIO_PIN_SET      /* 灭 = 输出高电平 */

/* ---- LED2：外接 LED，接 PB12，高电平点亮 ---- */
#define LED2_PORT        GPIOB
#define LED2_PIN         GPIO_PIN_12
#define LED2_ON_LEVEL    GPIO_PIN_SET
#define LED2_OFF_LEVEL   GPIO_PIN_RESET

void BSP_LED_Init(void);
void BSP_LED1_On(void);
void BSP_LED1_Off(void);
void BSP_LED1_Toggle(void);
void BSP_LED2_On(void);
void BSP_LED2_Off(void);
void BSP_LED2_Toggle(void);

#endif /* __BSP_LED_H */
