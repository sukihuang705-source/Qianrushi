﻿/**
  ******************************************************************************
  * @file    bsp_usart.h
  * @brief   串口1 板级驱动：PA9(TX) / PA10(RX)，默认 115200 8N1
  ******************************************************************************
  */

#ifndef __BSP_USART_H
#define __BSP_USART_H

#include "main.h"

extern UART_HandleTypeDef huart1;

void BSP_USART1_Init(uint32_t baudrate);
void uart_send_bytes(const uint8_t *buf, uint16_t len);
void uart_send_string(const char *str);
void uart_printf(const char *fmt, ...);

#endif /* __BSP_USART_H */
