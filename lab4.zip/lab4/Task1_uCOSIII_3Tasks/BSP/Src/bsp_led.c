﻿/**
  ******************************************************************************
  * @file    bsp_led.c
  * @brief   LED 板级驱动实现
  ******************************************************************************
  */

#include "bsp_led.h"

/**
  * @brief  LED 初始化：PC13、PB12 都配成推挽输出，并且先输出"灭"电平
  */
void BSP_LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    /* 先写电平再切模式，避免初始化瞬间闪一下 */
    HAL_GPIO_WritePin(LED1_PORT, LED1_PIN, LED1_OFF_LEVEL);
    HAL_GPIO_WritePin(LED2_PORT, LED2_PIN, LED2_OFF_LEVEL);

    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;

    GPIO_InitStruct.Pin = LED1_PIN;
    HAL_GPIO_Init(LED1_PORT, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = LED2_PIN;
    HAL_GPIO_Init(LED2_PORT, &GPIO_InitStruct);
}

void BSP_LED1_On(void)
{
    HAL_GPIO_WritePin(LED1_PORT, LED1_PIN, LED1_ON_LEVEL);
}

void BSP_LED1_Off(void)
{
    HAL_GPIO_WritePin(LED1_PORT, LED1_PIN, LED1_OFF_LEVEL);
}

void BSP_LED1_Toggle(void)
{
    HAL_GPIO_TogglePin(LED1_PORT, LED1_PIN);
}

void BSP_LED2_On(void)
{
    HAL_GPIO_WritePin(LED2_PORT, LED2_PIN, LED2_ON_LEVEL);
}

void BSP_LED2_Off(void)
{
    HAL_GPIO_WritePin(LED2_PORT, LED2_PIN, LED2_OFF_LEVEL);
}

void BSP_LED2_Toggle(void)
{
    HAL_GPIO_TogglePin(LED2_PORT, LED2_PIN);
}
