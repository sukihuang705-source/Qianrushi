﻿/**
  ******************************************************************************
  * @file    bsp_usart.c
  * @brief   串口1 板级驱动实现(查询方式发送，够实验用，也不用开中断)
  ******************************************************************************
  */

#include "bsp_usart.h"

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

UART_HandleTypeDef huart1;

/**
  * @brief  UART 底层初始化回调：时钟 + 引脚。HAL_UART_Init() 会自动调用它
  */
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();

        /* PA9 = USART1_TX，复用推挽输出 */
        GPIO_InitStruct.Pin   = GPIO_PIN_9;
        GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* PA10 = USART1_RX，上拉输入 */
        GPIO_InitStruct.Pin  = GPIO_PIN_10;
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLUP;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
    }
}

/**
  * @brief  串口1 初始化：115200 8N1，无硬件流控
  */
void BSP_USART1_Init(uint32_t baudrate)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = baudrate;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart1);
}

/**
  * @brief  发送一段字节(阻塞式，超时 100ms)
  */
void uart_send_bytes(const uint8_t *buf, uint16_t len)
{
    if ((buf == NULL) || (len == 0u))
    {
        return;
    }
    HAL_UART_Transmit(&huart1, (uint8_t *)buf, len, 100u);
}

/**
  * @brief  发送字符串
  */
void uart_send_string(const char *str)
{
    if (str == NULL)
    {
        return;
    }
    uart_send_bytes((const uint8_t *)str, (uint16_t)strlen(str));
}

/**
  * @brief  格式化输出(内部用 vsnprintf 拼串，所以支持 %d/%s/%02d 等)
  * @note   不要用 %f：MicroLIB 的 printf 不支持浮点，浮点转成整数再打印
  */
void uart_printf(const char *fmt, ...)
{
    char    buf[128];
    va_list ap;
    int     len;

    va_start(ap, fmt);
    len = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    if (len <= 0)
    {
        return;
    }
    if (len > (int)(sizeof(buf) - 1u))
    {
        len = (int)(sizeof(buf) - 1u);   /* 超长截断，保证只发缓冲区里的有效内容 */
    }
    uart_send_bytes((const uint8_t *)buf, (uint16_t)len);
}

/**
  * @brief  重定向 printf 到串口1(需要勾选 Use MicroLIB)
  */
int fputc(int ch, FILE *f)
{
    uint8_t c = (uint8_t)ch;

    (void)f;

    if (c == (uint8_t)'\n')
    {
        uint8_t cr = (uint8_t)'\r';
        HAL_UART_Transmit(&huart1, &cr, 1u, 100u);
    }
    HAL_UART_Transmit(&huart1, &c, 1u, 100u);
    return ch;
}
