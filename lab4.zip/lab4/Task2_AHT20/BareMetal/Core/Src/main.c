﻿/****************************************************************************
 * 文件名 : main.c
 * 实验   : 嵌入式实验四  任务二  AHT20 温湿度采集(裸机版)
 * 功能   : 用软件 I2C(PB6=SCL、PB7=SDA)读取 AHT20 的温湿度，
 *          每 2 秒通过串口1(PA9/PA10，115200)发到上位机。
 * 硬件   : AHT20 模块 VCC-3.3V  GND-GND  SCL-PB6  SDA-PB7(模块自带上拉)
 * 时钟   : 内部 HSI 8MHz(真机、软件仿真都能跑)
 ****************************************************************************/

#include "main.h"
#include "bsp_led.h"
#include "bsp_usart.h"
#include "bsp_aht20.h"

static void SystemClock_Config(void);
static void PrintTempHumi(float temperature, float humidity);

/****************************************************************************
 * 系统时钟 8MHz(内部 HSI，无 PLL)
 ****************************************************************************/
static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_OFF;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                       RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
    {
        Error_Handler();
    }
}

/****************************************************************************
 * 打印温湿度：把浮点数拆成"整数 + 两位小数"，避开 MicroLIB 不支持 %f 的问题
 ****************************************************************************/
static void PrintTempHumi(float temperature, float humidity)
{
    int32_t     t100  = (int32_t)(temperature * 100.0f + ((temperature >= 0.0f) ? 0.5f : -0.5f));
    int32_t     h100  = (int32_t)(humidity * 100.0f + 0.5f);
    const char *sign  = "";

    if (t100 < 0)
    {
        sign = "-";
        t100 = -t100;
    }

    uart_printf("温度: %s%d.%02d ℃   湿度: %d.%02d %%RH\r\n",
                sign, (int)(t100 / 100), (int)(t100 % 100),
                (int)(h100 / 100), (int)(h100 % 100));
}

/****************************************************************************
 * 主函数
 ****************************************************************************/
int main(void)
{
    float   temperature = 0.0f;
    float   humidity    = 0.0f;
    uint8_t ret;

    HAL_Init();
    SystemClock_Config();

    BSP_LED_Init();
    BSP_USART1_Init(115200);

    uart_send_string("\r\n===== 嵌入式实验四 任务二：AHT20 温湿度采集(裸机) =====\r\n");

    if (AHT20_Init() != 0u)
    {
        uart_send_string("[错误] AHT20 无应答：检查 PB6=SCL/PB7=SDA 接线，以及模块 VCC/GND 有没有接反\r\n");
    }
    else
    {
        uart_send_string("AHT20 初始化成功，开始每 2 秒采集一次...\r\n");
    }

    while (1)
    {
        ret = AHT20_ReadData(&temperature, &humidity);
        if (ret == 0u)
        {
            PrintTempHumi(temperature, humidity);
        }
        else
        {
            uart_printf("[错误] 采集失败，错误码 = %d（1=无应答 2=传感器忙 3=CRC 校验错）\r\n", (int)ret);
        }

        BSP_LED1_Toggle();     /* 顺手让板载 LED 闪一下，表示程序还活着 */
        HAL_Delay(2000);       /* 每 2 秒采集一次 */
    }
}

/****************************************************************************
 * 致命错误处理
 ****************************************************************************/
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
    }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
    while (1)
    {
    }
}
#endif
