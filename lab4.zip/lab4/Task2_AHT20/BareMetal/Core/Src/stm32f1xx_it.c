﻿/****************************************************************************
 * 文件名 : stm32f1xx_it.c
 * 功能   : 中断服务函数。任务2(PWM 呼吸灯)不需要外设中断，只保留内核异常
 *          处理和 SysTick 计时。SysTick 供 HAL_Delay 用。
 ****************************************************************************/

#include "main.h"

void NMI_Handler(void)
{
}

void HardFault_Handler(void)
{
    while (1) {}
}

void MemManage_Handler(void)
{
    while (1) {}
}

void BusFault_Handler(void)
{
    while (1) {}
}

void UsageFault_Handler(void)
{
    while (1) {}
}

void SVC_Handler(void)
{
}

void DebugMon_Handler(void)
{
}

void PendSV_Handler(void)
{
}

void SysTick_Handler(void)
{
    HAL_IncTick();
}
