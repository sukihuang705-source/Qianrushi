﻿/**
  ******************************************************************************
  * @file    bsp_aht20.c
  * @brief   AHT20 温湿度传感器驱动实现
  *
  * 【AHT20 的读数据流程】(见 AHT20 数据手册)
  *   1) 上电后等 40ms；
  *   2) 读状态字节，检查 bit3(校准标志)。若 bit3 = 0，说明没校准，
  *      要发"初始化/校准"命令 0xBE 0x08 0x00，等 10ms；
  *   3) 发"触发测量"命令 0xAC 0x33 0x00，等 80ms 转换；
  *   4) 连续读 7 个字节：状态(1) + 湿度/温度数据(5) + CRC(1)；
  *   5) 数据拼接：
  *        湿度 = 20bit 原始值 / 2^20 * 100  (%RH)
  *        温度 = 20bit 原始值 / 2^20 * 200 - 50 (℃)
  *      bit 定义：
  *        raw_h = (d[1] << 12) | (d[2] << 4) | (d[3] >> 4)
  *        raw_t = ((d[3] & 0x0F) << 16) | (d[4] << 8) | d[5]
  ******************************************************************************
  */

#include "bsp_aht20.h"
#include "bsp_usart.h"
#include "bsp_i2c_soft.h"

/* 调试开关：CRC 不对时把读到的 7 个字节打到串口，方便定位是数据错还是 CRC 字节错 */
#define AHT20_DEBUG_HEX   0

/* AHT20 用的 CRC8：多项式 0x31，初值 0xFF，不反射，结果不取反 */
static uint8_t AHT20_CRC8(const uint8_t *data, uint8_t len)
{
    uint8_t i;
    uint8_t crc = 0xFFu;

    while (len-- > 0u)
    {
        crc ^= *data++;
        for (i = 0; i < 8u; i++)
        {
            if ((crc & 0x80u) != 0u)
            {
                crc = (uint8_t)((crc << 1) ^ 0x31u);
            }
            else
            {
                crc = (uint8_t)(crc << 1);
            }
        }
    }
    return crc;
}

/**
  * @brief  向 AHT20 写一条命令
  * @retval 0 = 成功，1 = 从机无应答
  */
static uint8_t AHT20_WriteCmd(const uint8_t *cmd, uint8_t len)
{
    uint8_t i;

    I2C_Soft_Start();
    if (I2C_Soft_SendByte(AHT20_ADDR_W) != 0u)
    {
        I2C_Soft_Stop();
        return 1u;
    }
    for (i = 0; i < len; i++)
    {
        if (I2C_Soft_SendByte(cmd[i]) != 0u)
        {
            I2C_Soft_Stop();
            return 1u;
        }
    }
    I2C_Soft_Stop();
    return 0u;
}

/**
  * @brief  读 1 字节状态寄存器
  */
static uint8_t AHT20_ReadStatus(uint8_t *status)
{
    I2C_Soft_Start();
    if (I2C_Soft_SendByte(AHT20_ADDR_R) != 0u)
    {
        I2C_Soft_Stop();
        return 1u;
    }
    *status = I2C_Soft_ReadByte(0u);   /* 只读 1 字节，回 NACK */
    I2C_Soft_Stop();
    return 0u;
}

/**
  * @brief  初始化 AHT20：上电延时 + 检查/执行校准
  * @retval 0 = 成功，1 = 通信失败
  */
uint8_t AHT20_Init(void)
{
    uint8_t status = 0;
    const uint8_t init_cmd[3] = {0xBE, 0x08, 0x00};   /* 初始化/校准命令 */

    I2C_Soft_Init();
#if (AHT20_DEBUG_HEX != 0)   /* 调试打印：置 1 可看到总线空闲电平与状态字节 */
    /* 空闲电平自检：两根线被上拉拉高才正常。SDA=0 说明线被拉死或没上拉，
       此时读回来的数据会全是 0x00，看着像“通信正常但数据错”*/
    uart_printf("[I2C] idle level: SCL=%d SDA=%d (1=high; SDA=0 => shorted or no pull-up)\r\n",
                (HAL_GPIO_ReadPin(I2C_GPIO_PORT, I2C_SCL_PIN) == GPIO_PIN_SET) ? 1 : 0,
                (HAL_GPIO_ReadPin(I2C_GPIO_PORT, I2C_SDA_PIN) == GPIO_PIN_SET) ? 1 : 0);
#endif
    HAL_Delay(40);                                    /* 上电稳定时间 */

    if (AHT20_ReadStatus(&status) != 0u)
    {
        return 1u;
    }
#if (AHT20_DEBUG_HEX != 0)
    uart_printf("[I2C] status=0x%02X (bit3=calibrated)\r\n", status);
#endif

    /* bit3 = 校准标志，为 0 说明没校准 */
    if ((status & 0x08u) == 0u)
    {
        if (AHT20_WriteCmd(init_cmd, 3u) != 0u)
        {
            return 1u;
        }
        HAL_Delay(10);
    }

    return 0u;
}

/**
  * @brief  读一次温湿度
  * @param  temperature: 温度结果(℃)，humidity: 湿度结果(%RH)
  * @retval 0 = 成功，1 = 通信失败，2 = 传感器忙，3 = CRC 校验错
  */
uint8_t AHT20_ReadData(float *temperature, float *humidity)
{
    const uint8_t trigger_cmd[3] = {0xAC, 0x33, 0x00};   /* 触发测量命令 */
    uint8_t  buf[7];
    uint32_t raw_h;
    uint32_t raw_t;
    uint8_t  i;

    /* 1) 触发一次测量，等 80ms 转换 */
    if (AHT20_WriteCmd(trigger_cmd, 3u) != 0u)
    {
        return 1u;
    }
    HAL_Delay(80);

    /* 2) 连续读 7 字节 */
    I2C_Soft_Start();
    if (I2C_Soft_SendByte(AHT20_ADDR_R) != 0u)
    {
        I2C_Soft_Stop();
        return 1u;
    }
    for (i = 0; i < 7u; i++)
    {
        buf[i] = I2C_Soft_ReadByte((i == 6u) ? 0u : 1u);   /* 最后一字节回 NACK */
    }
    I2C_Soft_Stop();

    /* 3) 状态字节 bit7 = 忙标志 */
    if ((buf[0] & 0x80u) != 0u)
    {
        return 2u;
    }

    /* 4) CRC 校验(前 6 字节的 CRC8 应等于第 7 字节) */
    if (AHT20_CRC8(buf, 6u) != buf[6])
    {
#if (AHT20_DEBUG_HEX != 0)
        uart_printf("[CRC] raw=%02X %02X %02X %02X %02X %02X %02X  calc=%02X\r\n",
                    buf[0], buf[1], buf[2], buf[3], buf[4], buf[5], buf[6],
                    AHT20_CRC8(buf, 6u));
#endif
        return 3u;
    }

    /* 5) 拼出 20bit 原始值并换算 */
    raw_h = ((uint32_t)buf[1] << 12) | ((uint32_t)buf[2] << 4) | ((uint32_t)buf[3] >> 4);
    raw_t = (((uint32_t)buf[3] & 0x0Fu) << 16) | ((uint32_t)buf[4] << 8) | (uint32_t)buf[5];

    *humidity    = (float)raw_h * 100.0f / 1048576.0f;
    *temperature = (float)raw_t * 200.0f / 1048576.0f - 50.0f;

    return 0u;
}
