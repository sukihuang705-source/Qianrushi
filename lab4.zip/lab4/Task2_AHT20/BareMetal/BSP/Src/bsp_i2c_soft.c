﻿/**
  ******************************************************************************
  * @file    bsp_i2c_soft.c
  * @brief   软件模拟 I2C 实现
  *
  * 【软件 I2C 的原理】
  *   I2C 只有两根线：SCL(时钟)、SDA(数据)。
  *   - 空闲：两根线都被上拉电阻拉高；
  *   - 起始位(S)：SCL 高电平时，SDA 由高变低；
  *   - 停止位(P)：SCL 高电平时，SDA 由低变高；
  *   - 数据位：SCL 低电平时改变 SDA，SCL 高电平时 SDA 必须稳定(从机在这时采样)；
  *   - 应答位(ACK)：主机发完 8 位后释放 SDA，从机把 SDA 拉低表示"收到"。
  *   所谓"软件 I2C"，就是用 GPIO 口线 + 软件延时，按上面的时序一位一位地"掰"出来，
  *   不需要 MCU 内部专门的 I2C 外设。
  *
  * 【为什么用开漏输出】
  *   I2C 总线是"线与"结构：任何一个器件拉低，总线就是低。
  *   开漏输出只能主动拉低、不能主动拉高(高电平靠外部上拉电阻)，
  *   这样多个器件挂同一条总线才不会短路。
  ******************************************************************************
  */

#include "bsp_i2c_soft.h"

/* 口线操作宏：写 1 表示释放总线(靠上拉拉高)，写 0 表示主动拉低 */
#define SCL_H()     HAL_GPIO_WritePin(I2C_GPIO_PORT, I2C_SCL_PIN, GPIO_PIN_SET)
#define SCL_L()     HAL_GPIO_WritePin(I2C_GPIO_PORT, I2C_SCL_PIN, GPIO_PIN_RESET)
#define SDA_H()     HAL_GPIO_WritePin(I2C_GPIO_PORT, I2C_SDA_PIN, GPIO_PIN_SET)
#define SDA_L()     HAL_GPIO_WritePin(I2C_GPIO_PORT, I2C_SDA_PIN, GPIO_PIN_RESET)
#define SDA_READ()  HAL_GPIO_ReadPin(I2C_GPIO_PORT, I2C_SDA_PIN)

/**
  * @brief  软件延时：决定 I2C 的速率。
  *         8MHz 主频下大约几个微秒，SCL 频率约 100kHz，AHT20 完全能跟上。
  */
static void I2C_Delay(void)
{
    volatile uint32_t i = 8;
    while (i--)
    {
        __NOP();
    }
}

/**
  * @brief  初始化 SCL/SDA 为开漏输出，并让总线进入空闲状态(都为高)
  */
void I2C_Soft_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOB_CLK_ENABLE();

    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_OD;   /* 开漏输出 */
    GPIO_InitStruct.Pull  = GPIO_NOPULL;           /* 上拉靠外部电阻 */
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;

    GPIO_InitStruct.Pin = I2C_SCL_PIN;
    HAL_GPIO_Init(I2C_GPIO_PORT, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = I2C_SDA_PIN;
    HAL_GPIO_Init(I2C_GPIO_PORT, &GPIO_InitStruct);

    SCL_H();
    SDA_H();
    I2C_Delay();
}

/**
  * @brief  起始信号：SCL 高电平期间，SDA 由高变低
  */
void I2C_Soft_Start(void)
{
    SDA_H();
    I2C_Delay();
    SCL_H();
    I2C_Delay();
    SDA_L();          /* 产生下降沿 */
    I2C_Delay();
    SCL_L();          /* 钳住总线，准备发数据 */
    I2C_Delay();
}

/**
  * @brief  停止信号：SCL 高电平期间，SDA 由低变高
  */
void I2C_Soft_Stop(void)
{
    SDA_L();
    I2C_Delay();
    SCL_H();
    I2C_Delay();
    SDA_H();          /* 产生上升沿 */
    I2C_Delay();
}

/**
  * @brief  发送 1 字节(高位先发)，并读取从机应答
  * @retval 0 = ACK(从机拉低 SDA)，1 = NACK
  */
uint8_t I2C_Soft_SendByte(uint8_t byte)
{
    uint8_t i;
    uint8_t nack;

    for (i = 0; i < 8u; i++)
    {
        if ((byte & 0x80u) != 0u)
        {
            SDA_H();
        }
        else
        {
            SDA_L();
        }
        byte <<= 1;

        I2C_Delay();
        SCL_H();          /* 从机在 SCL 高电平期间采样 */
        I2C_Delay();
        SCL_L();
        I2C_Delay();
    }

    /* 第 9 个时钟：主机释放 SDA，读从机的应答 */
    SDA_H();
    I2C_Delay();
    SCL_H();
    I2C_Delay();
    nack = (SDA_READ() == GPIO_PIN_SET) ? 1u : 0u;   /* 高电平 = 没人应答 */
    SCL_L();
    I2C_Delay();

    return nack;
}

/**
  * @brief  读 1 字节(高位先读)，再由主机回 ACK/NACK
  * @param  ack: 1 = 回 ACK(还要继续读)，0 = 回 NACK(最后一个字节)
  */
uint8_t I2C_Soft_ReadByte(uint8_t ack)
{
    uint8_t i;
    uint8_t byte = 0;

    SDA_H();              /* 主机释放 SDA，交给从机驱动 */

    for (i = 0; i < 8u; i++)
    {
        byte <<= 1;
        I2C_Delay();
        SCL_H();
        I2C_Delay();
        if (SDA_READ() == GPIO_PIN_SET)
        {
            byte |= 0x01u;
        }
        SCL_L();
        I2C_Delay();
    }

    /* 第 9 个时钟：主机回 ACK/NACK */
    if (ack != 0u)
    {
        SDA_L();          /* ACK：主机拉低 */
    }
    else
    {
        SDA_H();          /* NACK：主机释放，保持高 */
    }
    I2C_Delay();
    SCL_H();
    I2C_Delay();
    SCL_L();
    SDA_H();              /* 释放 SDA */
    I2C_Delay();

    return byte;
}
