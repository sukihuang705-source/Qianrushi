﻿/**
  ******************************************************************************
  * @file    bsp_aht20.h
  * @brief   AHT20 温湿度传感器驱动(基于软件 I2C)
  *
  * AHT20：I2C 地址 0x38(7 位)，供电 2.2~5.5V，温度 -40~+85℃，
  *        湿度 0~100%RH，出厂已校准，上电后需要 40ms 稳定时间。
  ******************************************************************************
  */

#ifndef __BSP_AHT20_H
#define __BSP_AHT20_H

#include "main.h"

#define AHT20_I2C_ADDR      0x38u
#define AHT20_ADDR_W        ((AHT20_I2C_ADDR << 1) | 0x00u)   /* 0x70 写 */
#define AHT20_ADDR_R        ((AHT20_I2C_ADDR << 1) | 0x01u)   /* 0x71 读 */

/* 返回值：0 = 成功，1 = 无应答/通信失败，2 = 传感器忙，3 = CRC 校验错 */
uint8_t AHT20_Init(void);
uint8_t AHT20_ReadData(float *temperature, float *humidity);

#endif /* __BSP_AHT20_H */
