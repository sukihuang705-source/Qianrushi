﻿/**
  ******************************************************************************
  * @file    bsp_i2c_soft.h
  * @brief   软件模拟 I2C(用两个普通 GPIO 口线模拟 SCL/SDA)
  *
  * 引脚：PB6 = SCL，PB7 = SDA(和硬件 I2C1 同引脚，但这里是软件模拟)
  * 接法：两个引脚都配成"开漏输出"，外部各接一个 4.7k 上拉电阻到 3.3V。
  *       AHT20 模块一般自带上拉电阻，直接连即可。
  ******************************************************************************
  */

#ifndef __BSP_I2C_SOFT_H
#define __BSP_I2C_SOFT_H

#include "main.h"

#define I2C_GPIO_PORT   GPIOB
#define I2C_SCL_PIN     GPIO_PIN_6
#define I2C_SDA_PIN     GPIO_PIN_7

void    I2C_Soft_Init(void);
void    I2C_Soft_Start(void);
void    I2C_Soft_Stop(void);

/* 发送 1 字节，返回 0 表示从机应答(ACK)，返回 1 表示无应答(NACK) */
uint8_t I2C_Soft_SendByte(uint8_t byte);

/* 读 1 字节；ack = 1 时主机回 ACK(还要继续读)，ack = 0 时回 NACK(最后一个字节) */
uint8_t I2C_Soft_ReadByte(uint8_t ack);

#endif /* __BSP_I2C_SOFT_H */
