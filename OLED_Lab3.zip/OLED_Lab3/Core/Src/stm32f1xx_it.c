/**
  * @file    stm32f1xx_it.c
  * @brief   Cortex-M3 exception handlers.
  *
  * This project uses blocking I2C, so no peripheral IRQ handler is needed.
  * SysTick is used by HAL_Delay() and HAL_GetTick().
  */
#include "main.h"
#include "stm32f1xx_it.h"

void NMI_Handler(void)
{
}

void HardFault_Handler(void)
{
  while (1)
  {
  }
}

void MemManage_Handler(void)
{
  while (1)
  {
  }
}

void BusFault_Handler(void)
{
  while (1)
  {
  }
}

void UsageFault_Handler(void)
{
  while (1)
  {
  }
}

void SVC_Handler(void)
{
}

void DebugMon_Handler(void)
{
}

void PendSV_Handler(void)
{
}

void SysTick_Handler(void)
{
  HAL_IncTick();
}
