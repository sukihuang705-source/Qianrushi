#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"

/* Blue Pill onboard LED: PC13, active low. */
#define LED_PORT            GPIOC
#define LED_PIN             GPIO_PIN_13

/* User key: PB0 to GND, internal pull-up, active low. */
#define KEY_PORT            GPIOB
#define KEY_PIN             GPIO_PIN_0

extern I2C_HandleTypeDef hi2c1;

void Error_Handler(void);

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
