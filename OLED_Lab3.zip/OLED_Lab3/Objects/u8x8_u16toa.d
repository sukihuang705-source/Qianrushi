./objects/u8x8_u16toa.o: Middlewares\U8g2\u8x8_u16toa.c \
  Middlewares\U8g2\u8x8.h
