./objects/u8g2_buffer.o: Middlewares\U8g2\u8g2_buffer.c \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
