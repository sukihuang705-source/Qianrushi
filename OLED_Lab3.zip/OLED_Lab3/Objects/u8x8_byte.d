./objects/u8x8_byte.o: Middlewares\U8g2\u8x8_byte.c \
  Middlewares\U8g2\u8x8.h
