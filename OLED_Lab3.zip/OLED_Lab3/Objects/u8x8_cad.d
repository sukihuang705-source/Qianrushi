./objects/u8x8_cad.o: Middlewares\U8g2\u8x8_cad.c Middlewares\U8g2\u8x8.h
