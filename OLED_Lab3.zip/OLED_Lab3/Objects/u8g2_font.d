./objects/u8g2_font.o: Middlewares\U8g2\u8g2_font.c \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
