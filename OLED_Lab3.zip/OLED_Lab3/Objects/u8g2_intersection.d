./objects/u8g2_intersection.o: Middlewares\U8g2\u8g2_intersection.c \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
