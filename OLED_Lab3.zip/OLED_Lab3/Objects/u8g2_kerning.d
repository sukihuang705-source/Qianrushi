./objects/u8g2_kerning.o: Middlewares\U8g2\u8g2_kerning.c \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
