./objects/u8x8_capture.o: Middlewares\U8g2\u8x8_capture.c \
  Middlewares\U8g2\u8x8.h
