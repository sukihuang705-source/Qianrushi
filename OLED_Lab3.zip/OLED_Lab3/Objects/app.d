./objects/app.o: App\Src\app.c Core\Inc\main.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal.h \
  Core\Inc\stm32f1xx_hal_conf.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_rcc.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_def.h \
  Drivers\CMSIS\Device\ST\STM32F1xx\Include\stm32f1xx.h \
  Drivers\CMSIS\Device\ST\STM32F1xx\Include\stm32f103xb.h \
  Drivers\CMSIS\Core\Include\core_cm3.h \
  Drivers\CMSIS\Device\ST\STM32F1xx\Include\system_stm32f1xx.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_rcc_ex.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_gpio.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_gpio_ex.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_dma.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_dma_ex.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_cortex.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_flash.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_flash_ex.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_pwr.h \
  Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_i2c.h App\Inc\app.h \
  App\Inc\oled.h Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h \
  App\Inc\font_cn.h App\Inc\avatar.h App\Inc\app_config.h
