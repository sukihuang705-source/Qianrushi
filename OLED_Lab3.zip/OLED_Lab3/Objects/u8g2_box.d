./objects/u8g2_box.o: Middlewares\U8g2\u8g2_box.c Middlewares\U8g2\u8g2.h \
  Middlewares\U8g2\u8x8.h
