./objects/u8g2_circle.o: Middlewares\U8g2\u8g2_circle.c \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
