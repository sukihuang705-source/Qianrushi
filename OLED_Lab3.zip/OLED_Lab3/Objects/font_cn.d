./objects/font_cn.o: App\Src\font_cn.c App\Inc\font_cn.h \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
