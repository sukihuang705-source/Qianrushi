./objects/u8x8_display.o: Middlewares\U8g2\u8x8_display.c \
  Middlewares\U8g2\u8x8.h
