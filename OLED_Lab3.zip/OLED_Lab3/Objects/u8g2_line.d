./objects/u8g2_line.o: Middlewares\U8g2\u8g2_line.c \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
