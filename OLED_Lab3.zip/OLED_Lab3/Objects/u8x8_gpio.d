./objects/u8x8_gpio.o: Middlewares\U8g2\u8x8_gpio.c \
  Middlewares\U8g2\u8x8.h
