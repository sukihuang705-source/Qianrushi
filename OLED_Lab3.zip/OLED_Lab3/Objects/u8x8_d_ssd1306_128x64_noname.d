./objects/u8x8_d_ssd1306_128x64_noname.o: \
  Middlewares\U8g2\u8x8_d_ssd1306_128x64_noname.c \
  Middlewares\U8g2\u8x8.h
