./objects/u8g2_ll_hvline.o: Middlewares\U8g2\u8g2_ll_hvline.c \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
