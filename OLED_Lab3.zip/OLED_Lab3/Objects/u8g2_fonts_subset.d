./objects/u8g2_fonts_subset.o: Middlewares\U8g2\u8g2_fonts_subset.c \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
