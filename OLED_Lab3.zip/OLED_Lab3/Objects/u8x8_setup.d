./objects/u8x8_setup.o: Middlewares\U8g2\u8x8_setup.c \
  Middlewares\U8g2\u8x8.h
