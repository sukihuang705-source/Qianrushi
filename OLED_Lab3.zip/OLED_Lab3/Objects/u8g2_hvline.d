./objects/u8g2_hvline.o: Middlewares\U8g2\u8g2_hvline.c \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
