./objects/u8x8_8x8.o: Middlewares\U8g2\u8x8_8x8.c Middlewares\U8g2\u8x8.h
