./objects/u8g2_ssd1306_setup.o: Middlewares\U8g2\u8g2_ssd1306_setup.c \
  Middlewares\U8g2\u8g2.h Middlewares\U8g2\u8x8.h
