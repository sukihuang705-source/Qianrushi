#ifndef __OLED_H
#define __OLED_H

#include "u8g2.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 7-bit I2C address of the common 0.96" SSD1306 module. */
#define OLED_I2C_ADDR   0x3C

uint8_t OLED_Init(void);
uint8_t OLED_IsPresent(void);
u8g2_t *OLED_Get(void);

#ifdef __cplusplus
}
#endif

#endif
