#ifndef __AHT20_H
#define __AHT20_H

#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif

#define AHT20_I2C_ADDR   (0x38U << 1)

typedef struct
{
  float temperature_c;
  float humidity_rh;
  uint8_t valid;
} AHT20_Data_t;

uint8_t AHT20_Init(void);
uint8_t AHT20_Read(AHT20_Data_t *out);

#ifdef __cplusplus
}
#endif

#endif
