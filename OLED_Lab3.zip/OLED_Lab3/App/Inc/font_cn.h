#ifndef __FONT_CN_H
#define __FONT_CN_H

#include "u8g2.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
  const char *utf8;       /* 3-byte UTF-8 sequence */
  const uint8_t *bitmap;  /* 32 bytes, 16x16, row-major, MSB first */
  uint16_t codepoint;
} cn_glyph_t;

extern const cn_glyph_t g_cn_glyphs[];

const uint8_t *CN_GetGlyph(const char *utf8);
int CN_DrawChar(u8g2_t *u8g2, int x, int y, const char *utf8);
int CN_DrawText(u8g2_t *u8g2, int x, int y, const char *utf8);
int CN_TextWidth(const char *utf8);

/* Draw UTF-8 text; ASCII bytes use ascii_font (pass NULL to skip ASCII). */
int CN_DrawMixed(u8g2_t *u8g2, int x, int y, const char *utf8,
                 const uint8_t *ascii_font);
int CN_MixedWidth(const char *utf8, int ascii_width);

#ifdef __cplusplus
}
#endif

#endif