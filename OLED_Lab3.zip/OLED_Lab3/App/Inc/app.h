#ifndef __APP_H
#define __APP_H

#ifdef __cplusplus
extern "C" {
#endif

void App_Init(void);
void App_Task(void);

#ifdef __cplusplus
}
#endif

#endif
