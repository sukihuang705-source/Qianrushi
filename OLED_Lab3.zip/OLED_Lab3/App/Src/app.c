/**
  * @file    app.c
  * @brief   Five OLED screens: ID card, H-scroll, V-scroll,
  *          U8g2 graphics demo and animated avatar.
  *
  * One key on PB0 cycles the screens.  Debounce is 200 ms and the key is
  * polled from the main loop, so no EXTI/AFIO remap is needed.
  */
#include "main.h"
#include "app.h"
#include "oled.h"
#include "font_cn.h"
#include "avatar.h"
#include "app_config.h"

typedef enum
{
  SCREEN_ID = 0,
  SCREEN_HSCROLL,
  SCREEN_VSCROLL,
  SCREEN_DEMO,
  SCREEN_AVATAR,
  SCREEN_COUNT
} screen_id_t;

static u8g2_t *g_u;
static uint8_t g_oled_ok;
static uint8_t g_screen;
static uint8_t g_splash;
static uint8_t g_avatar_frame;

static uint32_t g_splash_ms;
static uint32_t g_last_draw;
static uint32_t g_last_retry;
static uint32_t g_btn_ms;
static int16_t g_scroll_x;
static int16_t g_scroll_y;

static uint8_t g_btn_raw = 1;
static uint8_t g_btn_latched = 0;

static void Draw_Splash(uint32_t elapsed);
static void Draw_ID(void);
static void Draw_HScroll(void);
static void Draw_VScroll(void);
static void Draw_Demo(uint32_t now);
static void Draw_Avatar(void);

static void TopBar(const char *title)
{
  u8g2_SetDrawColor(g_u, 1);
  u8g2_DrawBox(g_u, 0, 0, 128, 12);
  u8g2_SetDrawColor(g_u, 0);
  u8g2_SetFont(g_u, u8g2_font_6x10_tf);
  u8g2_DrawStr(g_u, 4, 9, title);
  u8g2_SetDrawColor(g_u, 1);
}

static uint8_t Button_Next(uint32_t now)
{
  uint8_t raw = HAL_GPIO_ReadPin(KEY_PORT, KEY_PIN);

  if (raw != g_btn_raw)
  {
    g_btn_raw = raw;
    g_btn_ms = now;
  }

  if ((raw == 0) && (g_btn_latched == 0) && ((now - g_btn_ms) >= 200))
  {
    g_btn_latched = 1;
    return 1;
  }

  if ((raw == 1) && ((now - g_btn_ms) >= 200))
  {
    g_btn_latched = 0;
  }
  return 0;
}

static void Enter_Screen(uint8_t s)
{
  g_screen = s;
  g_last_draw = 0;
  if (s == SCREEN_HSCROLL)
  {
    g_scroll_x = 128;
  }
  if (s == SCREEN_VSCROLL)
  {
    g_scroll_y = 64;
  }
  if (s == SCREEN_AVATAR)
  {
    g_avatar_frame = 0;
  }
}

void App_Init(void)
{
  g_u = OLED_Get();
  g_oled_ok = OLED_Init();
  g_splash = 1;
  g_splash_ms = HAL_GetTick();
  g_last_retry = g_splash_ms;
  g_btn_ms = g_splash_ms;
  g_screen = SCREEN_ID;
  g_scroll_x = 128;
  g_scroll_y = 64;

  if (g_oled_ok)
  {
    Draw_Splash(0);
    g_last_draw = HAL_GetTick();
  }
}

void App_Task(void)
{
  uint32_t now = HAL_GetTick();

  if (!g_oled_ok)
  {
    if ((now - g_last_retry) > 1000U)
    {
      g_last_retry = now;
      g_oled_ok = OLED_Init();
      if (g_oled_ok)
      {
        g_splash = 1;
        g_splash_ms = now;
        Draw_Splash(0);
      }
    }
    if ((now / 250U) & 1U)
    {
      HAL_GPIO_WritePin(LED_PORT, LED_PIN, GPIO_PIN_RESET);
    }
    else
    {
      HAL_GPIO_WritePin(LED_PORT, LED_PIN, GPIO_PIN_SET);
    }
    return;
  }

  if (Button_Next(now))
  {
    Enter_Screen((uint8_t)((g_screen + 1U) % SCREEN_COUNT));
  }

  if (g_splash)
  {
    uint32_t elapsed = now - g_splash_ms;
    if (elapsed < 1500U)
    {
      if ((now - g_last_draw) >= 40U)
      {
        Draw_Splash(elapsed);
        g_last_draw = now;
      }
      return;
    }
    g_splash = 0;
    g_last_draw = 0;
  }

  switch (g_screen)
  {
    case SCREEN_ID:
      if (g_last_draw == 0)
      {
        Draw_ID();
        g_last_draw = now;
      }
      break;

    case SCREEN_HSCROLL:
      if ((now - g_last_draw) >= 45U)
      {
        g_scroll_x -= 2;
        if (g_scroll_x < -(CN_MixedWidth(CN_MARQUEE, 6) + 8))
        {
          g_scroll_x = 128;
        }
        Draw_HScroll();
        g_last_draw = now;
      }
      break;

    case SCREEN_VSCROLL:
      if ((now - g_last_draw) >= 55U)
      {
        g_scroll_y--;
        if (g_scroll_y < -220)
        {
          g_scroll_y = 64;
        }
        Draw_VScroll();
        g_last_draw = now;
      }
      break;

    case SCREEN_DEMO:
      if ((now - g_last_draw) >= 70U)
      {
        Draw_Demo(now);
        g_last_draw = now;
      }
      break;

    case SCREEN_AVATAR:
      if ((now - g_last_draw) >= 180U)
      {
        g_avatar_frame = (uint8_t)((g_avatar_frame + 1U) % AVATAR_FRAME_COUNT);
        Draw_Avatar();
        g_last_draw = now;
      }
      break;

    default:
      break;
  }
}

static void Draw_Splash(uint32_t elapsed)
{
  uint8_t w = 0;

  u8g2_ClearBuffer(g_u);
  u8g2_SetDrawColor(g_u, 1);

  u8g2_SetFont(g_u, u8g2_font_8x13B_tf);
  u8g2_DrawStr(g_u, 48, 28, "U8g2");
  u8g2_SetFont(g_u, u8g2_font_6x10_tf);
  u8g2_DrawStr(g_u, 37, 42, "STM32F103");

  u8g2_DrawFrame(g_u, 16, 50, 96, 8);
  if (elapsed > 1500U)
  {
    elapsed = 1500U;
  }
  w = (uint8_t)((elapsed * 92U) / 1500U);
  if (w > 0)
  {
    u8g2_DrawBox(g_u, 18, 52, w, 4);
  }

  u8g2_SendBuffer(g_u);
}

static void Draw_ID(void)
{
  int nw;
  int iw;
  int nx;
  int ix;

  u8g2_ClearBuffer(g_u);
  TopBar("CQJTU  IoT 205");

  /* Name on its own line: 3 Chinese glyphs = 48 px. */
  nw = CN_TextWidth(APP_STUDENT_NAME);
  nx = (128 - nw) / 2;
  CN_DrawText(g_u, nx, 13, APP_STUDENT_NAME);

  /* 12-digit ID on the second line, 6x10 font = 72 px. */
  u8g2_SetFont(g_u, u8g2_font_6x10_tf);
  iw = (int)u8g2_GetStrWidth(g_u, APP_STUDENT_ID);
  ix = (128 - iw) / 2;
  u8g2_DrawStr(g_u, ix, 41, APP_STUDENT_ID);

  u8g2_DrawHLine(g_u, 8, 45, 112);

  /* School name on the last 16-pixel row. */
  nw = CN_TextWidth(CN_SCHOOL);
  nx = (128 - nw) / 2;
  CN_DrawText(g_u, nx, 48, CN_SCHOOL);

  u8g2_SendBuffer(g_u);
}

static void Draw_HScroll(void)
{
  u8g2_ClearBuffer(g_u);
  TopBar("SCROLL  LEFT");
  CN_DrawMixed(g_u, g_scroll_x, 20, CN_MARQUEE, u8g2_font_6x10_tf);
  u8g2_SetFont(g_u, u8g2_font_6x10_tf);
  u8g2_DrawStr(g_u, 4, 63, "PB0 -> NEXT  /  FULL BUFFER");
  u8g2_SendBuffer(g_u);
}

static void Draw_VScroll(void)
{
  const char *s = CN_SCROLL_VERT;
  int y = g_scroll_y;

  u8g2_ClearBuffer(g_u);
  TopBar("SCROLL  UP");

  while (*s != 0)
  {
    if (((uint8_t)*s & 0x80U) == 0)
    {
      s++;
      continue;
    }
    CN_DrawChar(g_u, 56, y, s);
    y += 18;
    s += 3;
  }

  u8g2_DrawVLine(g_u, 82, 16, 46);
  u8g2_SetFont(g_u, u8g2_font_8x13B_tf);
  u8g2_DrawStr(g_u, 94, 32, "205");
  u8g2_SetFont(g_u, u8g2_font_6x10_tf);
  u8g2_DrawStr(g_u, 92, 48, "IoT");
  u8g2_DrawStr(g_u, 4, 63, "PB0 -> NEXT");

  u8g2_SendBuffer(g_u);
}

static void Draw_Demo(uint32_t now)
{
  uint8_t t = (uint8_t)((now / 35U) % 120U);
  uint8_t bx;
  uint8_t by;

  u8g2_ClearBuffer(g_u);
  TopBar("U8g2  DEMO");

  u8g2_DrawRFrame(g_u, 2, 14, 124, 46, 5);
  u8g2_DrawLine(g_u, 4, 56, 124, 18);
  u8g2_DrawCircle(g_u, 24, 34, 11, U8G2_DRAW_ALL);
  u8g2_DrawDisc(g_u, 50, 34, 6, U8G2_DRAW_ALL);
  u8g2_DrawTriangle(g_u, 64, 50, 72, 22, 80, 50);

  u8g2_SetFont(g_u, u8g2_font_6x10_tf);
  u8g2_DrawStr(g_u, 88, 28, "128x64");
  u8g2_DrawStr(g_u, 88, 40, "SSD1306");
  u8g2_DrawStr(g_u, 84, 52, "I2C 400k");

  bx = (t < 60U) ? (uint8_t)(5U + t) : (uint8_t)(124U - t);
  by = (uint8_t)(18U + (t % 36U));
  u8g2_DrawDisc(g_u, bx, by, 2, U8G2_DRAW_ALL);

  u8g2_DrawBox(g_u, 46, 59, 36, 2);
  u8g2_SendBuffer(g_u);
}

static void Draw_Avatar(void)
{
  u8g2_ClearBuffer(g_u);
  u8g2_DrawXBMP(g_u, 64, 0, 64, 64, avatar_frames[g_avatar_frame]);
  u8g2_DrawVLine(g_u, 62, 0, 64);

  u8g2_SetFont(g_u, u8g2_font_7x13B_tf);
  u8g2_DrawStr(g_u, 4, 24, "HELLO");
  u8g2_SetFont(g_u, u8g2_font_6x10_tf);
  u8g2_DrawStr(g_u, 4, 38, "I am");
  u8g2_DrawStr(g_u, 4, 50, "Huang SK");
  u8g2_DrawStr(g_u, 4, 62, "IoT 205");

  u8g2_SendBuffer(g_u);
}
