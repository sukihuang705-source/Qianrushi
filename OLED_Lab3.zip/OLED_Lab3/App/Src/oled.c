/**
  * @file    oled.c
  * @brief   U8g2 port for SSD1306 128x64 on STM32F1 hardware I2C1.
  *
  * U8g2's byte callback protocol is small:
  *   START_TRANSFER -> SEND (one or more bytes) -> END_TRANSFER
  * The SSD1306 I2C "CAD" callback inserts 0x00 (command) or 0x40 (data)
  * as the first byte, so this file only has to put the bytes on the bus.
  */
#include "main.h"
#include "oled.h"
#include <string.h>

extern I2C_HandleTypeDef hi2c1;

static u8g2_t g_u8g2;
static uint8_t g_present = 0;
static uint8_t g_i2c_buf[192];
static uint16_t g_i2c_len = 0;

static uint8_t u8x8_byte_stm32_hw_i2c(u8x8_t *u8x8, uint8_t msg,
                                      uint8_t arg_int, void *arg_ptr)
{
  uint8_t *p;

  switch (msg)
  {
    case U8X8_MSG_BYTE_INIT:
      return 1;

    case U8X8_MSG_BYTE_SET_DC:
      return 1;

    case U8X8_MSG_BYTE_START_TRANSFER:
      g_i2c_len = 0;
      return 1;

    case U8X8_MSG_BYTE_SEND:
      p = (uint8_t *)arg_ptr;
      while (arg_int-- > 0)
      {
        if (g_i2c_len < sizeof(g_i2c_buf))
        {
          g_i2c_buf[g_i2c_len++] = *p++;
        }
        else
        {
          p++;
        }
      }
      return 1;

    case U8X8_MSG_BYTE_END_TRANSFER:
      if (g_i2c_len > 0)
      {
        /* u8x8_GetI2CAddress() is already the 8-bit write address. */
        HAL_I2C_Master_Transmit(&hi2c1, u8x8_GetI2CAddress(u8x8),
                                g_i2c_buf, g_i2c_len, 100);
      }
      g_i2c_len = 0;
      return 1;

    default:
      return 1;
  }
}

static uint8_t u8x8_gpio_and_delay_stm32(u8x8_t *u8x8, uint8_t msg,
                                         uint8_t arg_int, void *arg_ptr)
{
  (void)u8x8;
  (void)arg_ptr;

  switch (msg)
  {
    case U8X8_MSG_GPIO_AND_DELAY_INIT:
      return 1;

    case U8X8_MSG_DELAY_MILLI:
      HAL_Delay(arg_int);
      return 1;

    case U8X8_MSG_DELAY_10MICRO:
      for (volatile uint8_t i = 0; i < 8; i++)
      {
        __NOP();
      }
      return 1;

    case U8X8_MSG_DELAY_100NANO:
      __NOP();
      return 1;

    default:
      return 1;
  }
}

static uint8_t OLED_Scan(void)
{
  uint8_t addr;

  for (addr = OLED_I2C_ADDR; addr <= (OLED_I2C_ADDR + 1); addr++)
  {
    if (HAL_I2C_IsDeviceReady(&hi2c1, (uint16_t)(addr << 1), 2, 20) == HAL_OK)
    {
      return addr;
    }
  }
  return 0;
}

uint8_t OLED_Init(void)
{
  uint8_t addr = OLED_Scan();

  if (addr == 0)
  {
    g_present = 0;
    return 0;
  }

  u8g2_Setup_ssd1306_i2c_128x64_noname_f(&g_u8g2, U8G2_R0,
                                         u8x8_byte_stm32_hw_i2c,
                                         u8x8_gpio_and_delay_stm32);
  u8x8_SetI2CAddress(&g_u8g2.u8x8, (uint8_t)(addr << 1));

  u8g2_InitDisplay(&g_u8g2);
  u8g2_SetPowerSave(&g_u8g2, 0);
  u8g2_SetContrast(&g_u8g2, 180);
  u8g2_ClearBuffer(&g_u8g2);
  u8g2_SendBuffer(&g_u8g2);

  g_present = 1;
  return 1;
}

uint8_t OLED_IsPresent(void)
{
  return g_present;
}

u8g2_t *OLED_Get(void)
{
  return &g_u8g2;
}
