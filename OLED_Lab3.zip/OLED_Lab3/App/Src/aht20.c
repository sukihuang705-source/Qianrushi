/**
  * @file    aht20.c
  * @brief   Minimal AHT20 temperature/humidity driver (I2C, 3.3 V).
  *
  * AHT20 and SSD1306 share I2C1 (PB6/PB7) and have different addresses:
  *   AHT20  : 0x38 (7-bit)
  *   SSD1306: 0x3C (7-bit, some modules 0x3D)
  */
#include "aht20.h"

extern I2C_HandleTypeDef hi2c1;

static uint8_t AHT20_ReadStatus(uint8_t *status)
{
  return (HAL_I2C_Master_Receive(&hi2c1, AHT20_I2C_ADDR, status, 1, 100) == HAL_OK);
}

uint8_t AHT20_Init(void)
{
  uint8_t status = 0;
  uint8_t cmd[3] = {0xBE, 0x08, 0x00};

  if (HAL_I2C_IsDeviceReady(&hi2c1, AHT20_I2C_ADDR, 2, 30) != HAL_OK)
  {
    return 0;
  }

  HAL_Delay(40);

  if (AHT20_ReadStatus(&status) == 0)
  {
    return 0;
  }

  /* Bit3 = calibrated, bit4 = busy.  Calibrate only when needed. */
  if ((status & 0x18U) != 0x18U)
  {
    if (HAL_I2C_Master_Transmit(&hi2c1, AHT20_I2C_ADDR, cmd, 3, 100) != HAL_OK)
    {
      return 0;
    }
    HAL_Delay(10);
  }

  return 1;
}

uint8_t AHT20_Read(AHT20_Data_t *out)
{
  uint8_t cmd[3] = {0xAC, 0x33, 0x00};
  uint8_t d[6];
  uint32_t raw_h, raw_t;

  if (out == 0)
  {
    return 0;
  }

  out->valid = 0;
  if (HAL_I2C_Master_Transmit(&hi2c1, AHT20_I2C_ADDR, cmd, 3, 100) != HAL_OK)
  {
    return 0;
  }

  /* Conversion time is 75 ms max; 80 ms is safe and still responsive. */
  HAL_Delay(80);

  if (HAL_I2C_Master_Receive(&hi2c1, AHT20_I2C_ADDR, d, 6, 100) != HAL_OK)
  {
    return 0;
  }

  if ((d[0] & 0x80U) != 0)
  {
    return 0;   /* still busy */
  }

  raw_h = ((uint32_t)d[1] << 12) | ((uint32_t)d[2] << 4) | ((uint32_t)d[3] >> 4);
  raw_t = (((uint32_t)d[3] & 0x0FU) << 16) | ((uint32_t)d[4] << 8) | d[5];

  out->humidity_rh = ((float)raw_h * 100.0f) / 1048576.0f;
  out->temperature_c = ((float)raw_t * 200.0f) / 1048576.0f - 50.0f;
  out->valid = 1;
  return 1;
}
