# STM32F103C8T6 OLED / U8g2 实验

实验 3：OLED 显示。工程用 **STM32F103C8T6 + HAL + U8g2 + SSD1306 128x64（I2C）**。

> 当前显示内容里的学号/姓名是 `632407030316 / 黄诗凯`，改 `App/Inc/app_config.h` 即可。改中文名时还要在 `tools/gen_font_cn.ps1` 里加对应码点并重新生成字库。

## 1. 功能

一个 PB0 按键循环切换 5 屏：

| 屏 | 内容 |
|---|---|
| 1 | 学号 + 姓名 + 重庆交通大学 |
| 2 | 长字符串左右滚动（整屏缓冲刷新） |
| 3 | 长字符串上下滚动 |
| 4 | U8g2 图形 demo（线、圆、三角、圆角框、动画小球） |
| 5 | 64×64 机器人头像，4 帧眨眼/微笑动画 |

AHT20 本次没有原件，老师允许先不做，所以主界面不再显示模拟温湿度；`App/Src/aht20.c` 驱动源码先保留，等模块到了再加回屏幕。

## 2. 接线

| STM32F103C8T6 | SSD1306 |
|---|---|
| 3.3V | VCC |
| GND | GND |
| PB6 | SCL |
| PB7 | SDA |

- I2C1，400 kHz，7 位地址：OLED `0x3C`（少数模块 `0x3D`）。
- SCL/SDA 各接一个 4.7 kΩ 上拉到 3.3V。模块自带上拉时可以不重复接。
- ST-Link 只接 SWDIO / SWCLK / GND / 3.3V，用于下载调试，不参与 I2C。
- PB0 按键另一端接 GND，内部上拉，按下为低。

![接线图](Docs/wiring.png)

## 3. 编译和烧录

1. 用 Keil MDK 5.40 打开 `OLED_Lab3.uvprojx`。
2. 工程已经设置：AC6、MicroLIB、`USE_HAL_DRIVER,STM32F103xB`、C99。
3. `Options for Target -> Debug` 选 **ST-Link Debugger**。
4. `Settings -> Flash Download` 勾 **Reset and Run**，否则烧完要手动按 RESET。
5. Build（F7），Download（F8）。

命令行只用于编译验证（链接仍建议用 Keil GUI，避免中文路径的 `--libpath` 问题）：

```powershell
$cc = 'C:\Users\黄诗凯\AppData\Local\Keil_v5\ARM\ARMCLANG\bin\armclang.exe'
# 在工程根目录执行，包含路径见 OLED_Lab3.uvprojx
```

本机已经用 armclang + armlink 验证过：`Code + RO Data ≈ 27.0 KB`，`RW + ZI ≈ 3.1 KB`，F103C8 的 64 KB Flash / 20 KB RAM 足够。

## 4. 目录

```
OLED_Lab3/
  Core/                 main.c, 中断, HAL MSP, HAL 配置
  App/                  app.c, oled.c, aht20.c, font_cn.c
  Middlewares/U8g2/     裁剪后的 U8g2 核心 + SSD1306 驱动 + 3 个 ASCII 字体
  Drivers/              STM32F1 HAL + CMSIS
  startup_stm32f103xb.s
  OLED_Lab3.uvprojx
  OLED_Lab3.sct         仅用于命令行链接验证
```

## 5. 关键实现

### 5.1 时钟

只用内部 HSI 8 MHz，不开 HSE、不开 PLL。这样 Keil 仿真器也能跑，逻辑分析仪不会卡在“等外部晶振”。

### 5.2 U8g2 的 I2C 回调

U8g2 的 SSD1306 I2C 驱动会在每个传输前加控制字节：`0x00` 命令、`0x40` 数据。所以我们只需要把 `START -> SEND... -> END` 这一串字节通过 HAL 发出去：

```c
case U8X8_MSG_BYTE_START_TRANSFER:
  g_i2c_len = 0;
  return 1;
case U8X8_MSG_BYTE_SEND:
  /* append arg_int bytes to g_i2c_buf */
case U8X8_MSG_BYTE_END_TRANSFER:
  HAL_I2C_Master_Transmit(&hi2c1, u8x8_GetI2CAddress(u8x8),
                          g_i2c_buf, g_i2c_len, 100);
```

`u8x8_GetI2CAddress()` 返回的是已经左移一位的 8 位写地址，HAL 正好要这个格式。

### 5.3 只保留用得到的 U8g2

完整 `u8g2_fonts.c` 约 40 MB，编译进 64 KB 的 F103 不现实。工程里只保留：

- U8g2 核心：setup / buffer / hvline / font / box / circle / line / bitmap / polygon / intersection / kerning
- SSD1306 128×64 驱动 + `u8x8_cad_ssd13xx_fast_i2c`
- 3 个 ASCII 字体：`6x10`、`7x13B`、`8x13B`

汉字没有用 U8g2 的 wqy 全字库（`wqy12` 也有 200 KB），而是用 16×16 点阵，只取本实验用到的 47 个汉字/标点，约 1.5 KB。这样既讲清楚汉字点阵原理，也不会把 Flash 撑爆。

## 6. 改学号 / 姓名

打开 `App/Inc/app_config.h`：

```c
#define APP_STUDENT_ID          "632407030316"
#define APP_STUDENT_NAME        "\xE9\xBB\x84\xE8\xAF\x97\xE5\x87\xAF"   /* 黄诗凯 */
```

姓名用 UTF-8 字节转义，避免 Keil 在非 UTF-8 语言环境下把源码里的中文读坏。

换名字时：

1. 在 `tools/gen_font_cn.ps1` 的 `$codes` 里加上新字的 Unicode 码点。
2. 运行 `powershell -ExecutionPolicy Bypass -File tools/gen_font_cn.ps1`。
3. 重新编译。

## 7. GitHub

```powershell
cd D:\STM32_LAB_OLED\OLED_Lab3
git init
git add .
git commit -m "STM32F103 OLED: U8g2 + SSD1306"
git branch -M main
git remote add origin https://github.com/<your-name>/<repo>.git
git push -u origin main
```

不要提交 `Objects/`、`Listings/`、`DebugConfig/`、`*.uvguix.*`、`*.uvoptx`。

## 8. 常见问题

- **OLED 不亮**：先确认 3.3V/GND，再确认地址是 0x3C 还是 0x3D；代码里 `OLED_Scan()` 两个都试。
- **花屏/随机点**：I2C 线太长、没有上拉、或 400 kHz 下杜邦线质量差；先把 `hi2c1.Init.ClockSpeed` 改成 100000 试试。
- **烧完不跑**：Flash Download 里勾 `Reset and Run`。
- **中文是乱码**：不要直接改 `font_cn.c` 的字节，按第 6 节重新生成。
- **Keil 逻辑分析仪没有波形**：硬件 I2C 的引脚不一定能被虚拟逻辑分析仪观察到；报告任务 2 里有说明。

## 9. 许可

U8g2 为 BSD-2-Clause，见 `Middlewares/U8g2/u8g2.h` 文件头。ST HAL/CMSIS 遵循 ST 的许可证。其余为本实验代码。
