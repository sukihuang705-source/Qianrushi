/*
 * Minimal U8g2 setup for a 0.96" 128x64 SSD1306 over hardware I2C.
 *
 * U8g2's stock u8g2_d_setup.c is 460 kB because it contains setup
 * functions for hundreds of displays.  For this project only the full
 * buffer SSD1306 128x64 I2C constructor is needed, so it is copied here
 * together with its 1024-byte frame buffer allocator.
 */
#include "u8g2.h"

uint8_t *u8g2_m_16_8_f(uint8_t *page_cnt)
{
  static uint8_t buf[1024];
  *page_cnt = 8;
  return buf;
}

void u8g2_Setup_ssd1306_i2c_128x64_noname_f(u8g2_t *u8g2,
                                             const u8g2_cb_t *rotation,
                                             u8x8_msg_cb byte_cb,
                                             u8x8_msg_cb gpio_and_delay_cb)
{
  uint8_t tile_buf_height;
  uint8_t *buf;

  u8g2_SetupDisplay(u8g2, u8x8_d_ssd1306_128x64_noname,
                    u8x8_cad_ssd13xx_fast_i2c,
                    byte_cb, gpio_and_delay_cb);
  buf = u8g2_m_16_8_f(&tile_buf_height);
  u8g2_SetupBuffer(u8g2, buf, tile_buf_height,
                   u8g2_ll_hvline_vertical_top_lsb, rotation);
}
