@****************************************************************************
@ File: startup_stm32f103xb.s  (GNU assembler syntax version)
@ Target: STM32F103C8T6 (medium density, Cortex-M3)
@
@ 用 GNU 语法、不用 armasm 语法，是为了绕开 Keil AC6 中文路径报
@ "Unable to convert command-line to UTF-16" 的问题(见 Lab1/Lab2 同款做法)。
@
@ 作用：定义中断向量表，复位后先调 SystemInit()，再进 C 库的 __main(最终调 main)。
@ 所有中断处理函数先用"弱别名"指向 Default_Handler，用户在 stm32f1xx_it.c 里
@ 定义的强符号(如 SysTick_Handler、EXTI1_IRQHandler)会自动覆盖它们。
@****************************************************************************

    .syntax unified
    .cpu    cortex-m3
    .thumb
    .eabi_attribute 25, 1          @ PRESERVE8: 8 字节对齐

    .equ    Stack_Size, 0x400      @ 栈 1KB
    .equ    Heap_Size,  0x200      @ 堆 512B


@ ==================== 向量表 ====================
    .section RESET, "a", %progbits
    .globl  __Vectors
__Vectors:
    .word   __initial_sp           @ 栈顶
    .word   Reset_Handler          @ 复位

    .word   NMI_Handler
    .word   HardFault_Handler
    .word   MemManage_Handler
    .word   BusFault_Handler
    .word   UsageFault_Handler
    .word   0                      @ 保留
    .word   0
    .word   0
    .word   0
    .word   SVC_Handler
    .word   DebugMon_Handler
    .word   0
    .word   PendSV_Handler
    .word   SysTick_Handler

    .word   WWDG_IRQHandler
    .word   PVD_IRQHandler
    .word   TAMPER_IRQHandler
    .word   RTC_IRQHandler
    .word   FLASH_IRQHandler
    .word   RCC_IRQHandler
    .word   EXTI0_IRQHandler
    .word   EXTI1_IRQHandler
    .word   EXTI2_IRQHandler
    .word   EXTI3_IRQHandler
    .word   EXTI4_IRQHandler
    .word   DMA1_Channel1_IRQHandler
    .word   DMA1_Channel2_IRQHandler
    .word   DMA1_Channel3_IRQHandler
    .word   DMA1_Channel4_IRQHandler
    .word   DMA1_Channel5_IRQHandler
    .word   DMA1_Channel6_IRQHandler
    .word   DMA1_Channel7_IRQHandler
    .word   ADC1_2_IRQHandler
    .word   USB_HP_CAN1_TX_IRQHandler
    .word   USB_LP_CAN1_RX0_IRQHandler
    .word   CAN1_RX1_IRQHandler
    .word   CAN1_SCE_IRQHandler
    .word   EXTI9_5_IRQHandler
    .word   TIM1_BRK_IRQHandler
    .word   TIM1_UP_IRQHandler
    .word   TIM1_TRG_COM_IRQHandler
    .word   TIM1_CC_IRQHandler
    .word   TIM2_IRQHandler
    .word   TIM3_IRQHandler
    .word   TIM4_IRQHandler
    .word   I2C1_EV_IRQHandler
    .word   I2C1_ER_IRQHandler
    .word   I2C2_EV_IRQHandler
    .word   I2C2_ER_IRQHandler
    .word   SPI1_IRQHandler
    .word   SPI2_IRQHandler
    .word   USART1_IRQHandler
    .word   USART2_IRQHandler
    .word   USART3_IRQHandler
    .word   EXTI15_10_IRQHandler
    .word   RTC_Alarm_IRQHandler
    .word   USBWakeUp_IRQHandler
    .word   0                      @ 保留 x6
    .word   0
    .word   0
    .word   0
    .word   0
    .word   0
    .word   0xF108F85F             @ BootRAM 魔数(RAM 启动用，flash 启动不关心)


@ ==================== 复位处理 ====================
    .section .text
    .thumb_func
    .globl  Reset_Handler
Reset_Handler:
    ldr     r0, =SystemInit        @ 配置系统时钟(在 system_stm32f1xx.c 里)
    blx     r0
    ldr     r0, =__main            @ 进 C 库 __main，最终调用 main()
    bx      r0


@ ==================== 默认处理(死循环) ====================
    .thumb_func
Default_Handler:
    b       .


@ ==================== 弱别名：没被用户重写的中断都落到 Default_Handler ====================
    .weak   NMI_Handler
    .thumb_set NMI_Handler, Default_Handler
    .weak   HardFault_Handler
    .thumb_set HardFault_Handler, Default_Handler
    .weak   MemManage_Handler
    .thumb_set MemManage_Handler, Default_Handler
    .weak   BusFault_Handler
    .thumb_set BusFault_Handler, Default_Handler
    .weak   UsageFault_Handler
    .thumb_set UsageFault_Handler, Default_Handler
    .weak   SVC_Handler
    .thumb_set SVC_Handler, Default_Handler
    .weak   DebugMon_Handler
    .thumb_set DebugMon_Handler, Default_Handler
    .weak   PendSV_Handler
    .thumb_set PendSV_Handler, Default_Handler
    .weak   SysTick_Handler
    .thumb_set SysTick_Handler, Default_Handler

    .weak   WWDG_IRQHandler
    .thumb_set WWDG_IRQHandler, Default_Handler
    .weak   PVD_IRQHandler
    .thumb_set PVD_IRQHandler, Default_Handler
    .weak   TAMPER_IRQHandler
    .thumb_set TAMPER_IRQHandler, Default_Handler
    .weak   RTC_IRQHandler
    .thumb_set RTC_IRQHandler, Default_Handler
    .weak   FLASH_IRQHandler
    .thumb_set FLASH_IRQHandler, Default_Handler
    .weak   RCC_IRQHandler
    .thumb_set RCC_IRQHandler, Default_Handler
    .weak   EXTI0_IRQHandler
    .thumb_set EXTI0_IRQHandler, Default_Handler
    .weak   EXTI1_IRQHandler
    .thumb_set EXTI1_IRQHandler, Default_Handler
    .weak   EXTI2_IRQHandler
    .thumb_set EXTI2_IRQHandler, Default_Handler
    .weak   EXTI3_IRQHandler
    .thumb_set EXTI3_IRQHandler, Default_Handler
    .weak   EXTI4_IRQHandler
    .thumb_set EXTI4_IRQHandler, Default_Handler
    .weak   DMA1_Channel1_IRQHandler
    .thumb_set DMA1_Channel1_IRQHandler, Default_Handler
    .weak   DMA1_Channel2_IRQHandler
    .thumb_set DMA1_Channel2_IRQHandler, Default_Handler
    .weak   DMA1_Channel3_IRQHandler
    .thumb_set DMA1_Channel3_IRQHandler, Default_Handler
    .weak   DMA1_Channel4_IRQHandler
    .thumb_set DMA1_Channel4_IRQHandler, Default_Handler
    .weak   DMA1_Channel5_IRQHandler
    .thumb_set DMA1_Channel5_IRQHandler, Default_Handler
    .weak   DMA1_Channel6_IRQHandler
    .thumb_set DMA1_Channel6_IRQHandler, Default_Handler
    .weak   DMA1_Channel7_IRQHandler
    .thumb_set DMA1_Channel7_IRQHandler, Default_Handler
    .weak   ADC1_2_IRQHandler
    .thumb_set ADC1_2_IRQHandler, Default_Handler
    .weak   USB_HP_CAN1_TX_IRQHandler
    .thumb_set USB_HP_CAN1_TX_IRQHandler, Default_Handler
    .weak   USB_LP_CAN1_RX0_IRQHandler
    .thumb_set USB_LP_CAN1_RX0_IRQHandler, Default_Handler
    .weak   CAN1_RX1_IRQHandler
    .thumb_set CAN1_RX1_IRQHandler, Default_Handler
    .weak   CAN1_SCE_IRQHandler
    .thumb_set CAN1_SCE_IRQHandler, Default_Handler
    .weak   EXTI9_5_IRQHandler
    .thumb_set EXTI9_5_IRQHandler, Default_Handler
    .weak   TIM1_BRK_IRQHandler
    .thumb_set TIM1_BRK_IRQHandler, Default_Handler
    .weak   TIM1_UP_IRQHandler
    .thumb_set TIM1_UP_IRQHandler, Default_Handler
    .weak   TIM1_TRG_COM_IRQHandler
    .thumb_set TIM1_TRG_COM_IRQHandler, Default_Handler
    .weak   TIM1_CC_IRQHandler
    .thumb_set TIM1_CC_IRQHandler, Default_Handler
    .weak   TIM2_IRQHandler
    .thumb_set TIM2_IRQHandler, Default_Handler
    .weak   TIM3_IRQHandler
    .thumb_set TIM3_IRQHandler, Default_Handler
    .weak   TIM4_IRQHandler
    .thumb_set TIM4_IRQHandler, Default_Handler
    .weak   I2C1_EV_IRQHandler
    .thumb_set I2C1_EV_IRQHandler, Default_Handler
    .weak   I2C1_ER_IRQHandler
    .thumb_set I2C1_ER_IRQHandler, Default_Handler
    .weak   I2C2_EV_IRQHandler
    .thumb_set I2C2_EV_IRQHandler, Default_Handler
    .weak   I2C2_ER_IRQHandler
    .thumb_set I2C2_ER_IRQHandler, Default_Handler
    .weak   SPI1_IRQHandler
    .thumb_set SPI1_IRQHandler, Default_Handler
    .weak   SPI2_IRQHandler
    .thumb_set SPI2_IRQHandler, Default_Handler
    .weak   USART1_IRQHandler
    .thumb_set USART1_IRQHandler, Default_Handler
    .weak   USART2_IRQHandler
    .thumb_set USART2_IRQHandler, Default_Handler
    .weak   USART3_IRQHandler
    .thumb_set USART3_IRQHandler, Default_Handler
    .weak   EXTI15_10_IRQHandler
    .thumb_set EXTI15_10_IRQHandler, Default_Handler
    .weak   RTC_Alarm_IRQHandler
    .thumb_set RTC_Alarm_IRQHandler, Default_Handler
    .weak   USBWakeUp_IRQHandler
    .thumb_set USBWakeUp_IRQHandler, Default_Handler


@ ==================== 栈和堆 ====================
    .section .bss
    .align  3
    .globl  __heap_base
__heap_base:
    .space  Heap_Size
    .globl  __heap_limit
__heap_limit:

    .globl  Stack_Mem
Stack_Mem:
    .space  Stack_Size
    .globl  __initial_sp
__initial_sp:

    .end
