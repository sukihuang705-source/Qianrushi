/**
  ******************************************************************************
  * @file    stm32f1xx_hal_conf.h
  * @brief   HAL 库配置文件：选择要用到的 HAL 模块、设 HSE 晶振频率
  *
  * 说明：本实验用到 GPIO、RCC、CORTEX(NVIC)、PWR、FLASH 几个模块，
  *       这里把它们对应的 MODULE_ENABLED 宏打开，其余关闭。
  *       如果用 CubeMX 生成工程，这个文件是自动生成好的，不用手写。
  ******************************************************************************
  */

#ifndef __STM32F1xx_HAL_CONF_H
#define __STM32F1xx_HAL_CONF_H

#ifdef __cplusplus
extern "C" {
#endif

/* ==================== 时钟相关 ==================== */
/* Blue Pill 板上晶振是 8MHz */
#define HSE_VALUE              8000000U
#define HSE_STARTUP_TIMEOUT    100U

/* 内部低速/高速时钟频率(默认值，不用改) */
#define HSI_VALUE              8000000U
#define LSI_VALUE              40000U
#define LSE_VALUE              32768U
#define LSE_STARTUP_TIMEOUT    5000U

/* 系统 PLL 输入源是 HSE，倍频系数等(在 SystemClock_Config 里实际配置) */
#define HSE_PREDIV_VALUE       1U

/* ==================== 系统配置 ==================== */
#define VDD_VALUE              3300U   /* 供电电压 mV */
#define TICK_INT_PRIORITY      0x0FU   /* SysTick 中断优先级(HAL_Delay 计时用) */
#define USE_RTOS               0U      /* 不用 RTOS */
#define PREFETCH_ENABLE        1U      /* 使能 Flash 预取 */

/* ==================== 模块开关(需要哪个打开哪个) ==================== */
#define HAL_MODULE_ENABLED          /* HAL 核心 */
#define HAL_GPIO_MODULE_ENABLED     /* GPIO 模块(含 EXTI 外部中断) */
#define HAL_RCC_MODULE_ENABLED      /* RCC 时钟模块 */
#define HAL_CORTEX_MODULE_ENABLED   /* NVIC 中断控制器 */
#define HAL_PWR_MODULE_ENABLED      /* 电源管理 */
#define HAL_FLASH_MODULE_ENABLED    /* Flash(配置等待周期要用) */
#define HAL_DMA_MODULE_ENABLED      /* DMA(部分函数依赖，开着保险) */
#define HAL_TIM_MODULE_ENABLED      /* 定时器模块(计数/PWM 要用) */

/* 本实验不用的模块，全部关闭
#define HAL_ADC_MODULE_ENABLED
#define HAL_CAN_MODULE_ENABLED
#define HAL_CEC_MODULE_ENABLED
#define HAL_I2C_MODULE_ENABLED
#define HAL_IWDG_MODULE_ENABLED
#define HAL_RTC_MODULE_ENABLED
#define HAL_SD_MODULE_ENABLED
#define HAL_SMARTCARD_MODULE_ENABLED
#define HAL_SPI_MODULE_ENABLED
#define HAL_TIM_MODULE_ENABLED
#define HAL_UART_MODULE_ENABLED
#define HAL_USART_MODULE_ENABLED
#define HAL_WWDG_MODULE_ENABLED
*/

/* ==================== 包含本实验用到的 HAL 模块头文件 ==================== */
/* 这些头会层层包含 stm32f1xx.h → core_cm3.h，从而定义 __IO/uint32_t 等类型，
   所以必须显式 include，否则 HAL 头里的类型会报"未定义"。 */
#ifdef HAL_RCC_MODULE_ENABLED
#include "stm32f1xx_hal_rcc.h"
#endif

#ifdef HAL_GPIO_MODULE_ENABLED
#include "stm32f1xx_hal_gpio.h"
#endif

#ifdef HAL_DMA_MODULE_ENABLED
#include "stm32f1xx_hal_dma.h"
#endif

#ifdef HAL_TIM_MODULE_ENABLED
#include "stm32f1xx_hal_tim.h"
#endif

#ifdef HAL_CORTEX_MODULE_ENABLED
#include "stm32f1xx_hal_cortex.h"
#endif

#ifdef HAL_FLASH_MODULE_ENABLED
#include "stm32f1xx_hal_flash.h"
#endif

#ifdef HAL_PWR_MODULE_ENABLED
#include "stm32f1xx_hal_pwr.h"
#endif

/* ==================== 断言 ==================== */
/* #define USE_FULL_ASSERT    1U */

#ifdef USE_FULL_ASSERT
  #define assert_param(expr) ((expr) ? (void)0U : assert_failed((uint8_t *)__FILE__, __LINE__))
  void assert_failed(uint8_t* file, uint32_t line);
#else
  #define assert_param(expr) ((void)0U)
#endif

#ifdef __cplusplus
}
#endif

#endif /* __STM32F1xx_HAL_CONF_H */
