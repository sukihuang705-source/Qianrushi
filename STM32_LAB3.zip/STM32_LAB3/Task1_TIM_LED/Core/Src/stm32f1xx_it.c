/****************************************************************************
 * 文件名 : stm32f1xx_it.c
 * 功能   : 中断服务函数集中放这里。本实验重点是 TIM2_IRQHandler(定时器2更新中断)，
 *          其余是 Cortex-M3 内核异常的标准处理。
 ****************************************************************************/

#include "main.h"

extern TIM_HandleTypeDef htim2;   /* main.c 里定义的定时器句柄 */

/* ---------------- Cortex-M3 内核异常处理(标准模板) ---------------- */

void NMI_Handler(void)
{
}

void HardFault_Handler(void)
{
    while (1) {}
}

void MemManage_Handler(void)
{
    while (1) {}
}

void BusFault_Handler(void)
{
    while (1) {}
}

void UsageFault_Handler(void)
{
    while (1) {}
}

void SVC_Handler(void)
{
}

void DebugMon_Handler(void)
{
}

void PendSV_Handler(void)
{
}

/* SysTick 中断：HAL_Delay 靠它计时，必须调用 HAL_IncTick() */
void SysTick_Handler(void)
{
    HAL_IncTick();
}

/* ---------------- 外设中断 ---------------- */

/* 定时器2更新中断：进中断后交给 HAL 的通用 TIM 中断处理，
   HAL 清标志位后回调 HAL_TIM_PeriodElapsedCallback，在那里翻转 PA0 */
void TIM2_IRQHandler(void)
{
    HAL_TIM_IRQHandler(&htim2);
}
