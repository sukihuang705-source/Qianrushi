/****************************************************************************
 * 文件名 : main.c
 * 实验   : 嵌入式实验三  任务1  定时器计数方式控制 LED 2s 周期亮灭
 * 功能   : TIM2 工作在定时器计数(时基)模式，每 1s 产生一次更新中断，
 *          在中断服务函数里翻转 PA0，让接在 PA0 上的 LED 以 2s 周期亮-灭
 *          (亮 1s + 灭 1s = 2s)。
 * 硬件   : LED 阳极经限流电阻(330Ω~1kΩ)接 PA0，阴极接 GND(高电平点亮)。
 * 时钟   : 使用内部 HSI 8MHz(不用外部晶振)，真机烧录和 Keil 软件仿真都能跑。
 ****************************************************************************/

#include "main.h"

TIM_HandleTypeDef htim2;   /* 定时器2句柄，定义为全局，供中断服务函数引用 */

void SystemClock_Config(void);
void TIM2_Init(void);


/****************************************************************************
 * 函数名 : SystemClock_Config
 * 功能   : 系统时钟配置为 8MHz(内部 HSI，无 PLL)
 * 说明   : 故意不用外部 HSE 晶振，因为 Keil 软件仿真器模拟不了 HSE，
 *          若用 HSE 会卡在"等待 HSE 就绪"处，逻辑分析仪就看不了波形。
 ****************************************************************************/
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_OFF;   /* 不用 PLL，直接用 8MHz */
    HAL_RCC_OscConfig(&RCC_OscInitStruct);

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                       RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0); /* 8MHz 用 0 等待周期 */
}


/****************************************************************************
 * 函数名 : TIM2_Init
 * 功能   : ① PA0 配成推挽输出(LED 引脚)
 *          ② TIM2 配成时基计数模式，1s 溢出一次
 *          ③ 打开更新中断并启动定时器
 ****************************************************************************/
void TIM2_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();   /* 开 GPIOA 时钟(PA0 要用) */
    __HAL_RCC_TIM2_CLK_ENABLE();    /* 开定时器2时钟 */

    /* PA0 做普通输出：定时器只管"计时"，引脚电平靠中断里手动翻转 */
    GPIO_InitStruct.Pin   = GPIO_PIN_0;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* TIM2 时基配置：TIM2 挂在 APB1，时钟 = 8MHz(HSI 不分频) */
    htim2.Instance               = TIM2;
    htim2.Init.Prescaler         = 7999;  /* 8MHz / 8000 = 1kHz */
    htim2.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim2.Init.Period            = 999;   /* 1kHz / 1000 = 1Hz → 每 1s 溢出一次 */
    htim2.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    HAL_TIM_Base_Init(&htim2);

    /* 打开 TIM2 更新中断 */
    HAL_NVIC_SetPriority(TIM2_IRQn, 2, 0);
    HAL_NVIC_EnableIRQ(TIM2_IRQn);

    /* 以中断方式启动定时器 */
    HAL_TIM_Base_Start_IT(&htim2);
}


/****************************************************************************
 * 函数名 : HAL_TIM_PeriodElapsedCallback
 * 功能   : 定时器更新中断回调(HAL 弱函数，发生更新事件后自动调用)
 *          每 1s 调用一次 → 翻转 PA0 → LED 2s 周期亮灭
 ****************************************************************************/
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM2)
    {
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_0);
    }
}


/****************************************************************************
 * 主函数
 ****************************************************************************/
int main(void)
{
    HAL_Init();             /* 复位外设、初始化 SysTick */
    SystemClock_Config();   /* 系统时钟 8MHz */
    TIM2_Init();            /* 定时器 + LED 引脚初始化 */

    while (1)
    {
        /* 主循环什么都不做，LED 在定时器中断里自动翻转 */
    }
}
