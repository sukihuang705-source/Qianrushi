/****************************************************************************
 * 文件名 : main.c
 * 实验   : 嵌入式实验三  任务2  定时器 PWM 模式实现 LED 呼吸灯
 * 功能   : TIM2 通道1(PA0)输出 PWM，主循环里不断改变占空比(CCR1)，
 *          让 LED 渐亮→渐灭循环，实现"呼吸灯"效果，呼吸周期约 2s。
 * 硬件   : LED 阳极经限流电阻(330Ω~1kΩ)接 PA0，阴极接 GND(高电平点亮)。
 * 观察   : 用 Keil 逻辑分析仪看 PA0(PORTA.0)的 PWM 波形，占空比在变。
 * 时钟   : 内部 HSI 8MHz(真机、软件仿真都能跑)。
 ****************************************************************************/

#include "main.h"

TIM_HandleTypeDef htim2;   /* 定时器2句柄 */

void SystemClock_Config(void);
void TIM2_PWM_Init(void);


/****************************************************************************
 * 系统时钟 8MHz(内部 HSI，无 PLL)——理由同任务1，便于软件仿真看波形
 ****************************************************************************/
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_OFF;
    HAL_RCC_OscConfig(&RCC_OscInitStruct);

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                       RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0);
}


/****************************************************************************
 * 函数名 : TIM2_PWM_Init
 * 功能   : ① PA0 配成复用推挽输出(TIM2_CH1)
 *          ② TIM2 配成 PWM 模式1，频率 1kHz，初始占空比 0
 *          ③ 启动 PWM 输出
 ****************************************************************************/
void TIM2_PWM_Init(void)
{
    GPIO_InitTypeDef   GPIO_InitStruct   = {0};
    TIM_OC_InitTypeDef TIM_OC_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();   /* 开 GPIOA 时钟 */
    __HAL_RCC_TIM2_CLK_ENABLE();    /* 开定时器2时钟 */

    /* PA0 复用为 TIM2_CH1(复用推挽输出) */
    GPIO_InitStruct.Pin       = GPIO_PIN_0;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* TIM2 时基：PWM 频率 = 8MHz/(7+1)/(999+1) = 1kHz */
    htim2.Instance               = TIM2;
    htim2.Init.Prescaler         = 7;     /* 8MHz / 8 = 1MHz */
    htim2.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim2.Init.Period            = 999;   /* 1MHz / 1000 = 1kHz(自动重装载值) */
    htim2.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    HAL_TIM_PWM_Init(&htim2);

    /* 通道1 配置为 PWM 模式1，初始占空比 0(LED 熄灭) */
    TIM_OC_InitStruct.OCMode     = TIM_OCMODE_PWM1;
    TIM_OC_InitStruct.Pulse      = 0;              /* CCR1 初值，0 = 占空比 0% */
    TIM_OC_InitStruct.OCPolarity = TIM_OCPOLARITY_HIGH;
    TIM_OC_InitStruct.OCFastMode = TIM_OCFAST_DISABLE;
    HAL_TIM_PWM_ConfigChannel(&htim2, &TIM_OC_InitStruct, TIM_CHANNEL_1);

    /* 启动 PWM 输出 */
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
}


/****************************************************************************
 * 主函数：呼吸灯
 * 占空比 0→100%→0 循环，步长 5、每步 5ms，一个完整呼吸周期约 2s。
 * 想调快/慢就改 HAL_Delay 时间；想更平滑就减小步长。
 ****************************************************************************/
int main(void)
{
    int32_t duty = 0;   /* 占空比，用有符号数避免减到负数时溢出成死循环 */

    HAL_Init();
    SystemClock_Config();
    TIM2_PWM_Init();

    while (1)
    {
        /* ---- 渐亮：占空比 0 → 100% ---- */
        for (duty = 0; duty <= 999; duty += 5)
        {
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, duty);
            HAL_Delay(5);          /* 1000/5 × 5ms ≈ 1s 渐亮 */
        }

        /* ---- 渐灭：占空比 100% → 0 ---- */
        for (duty = 999; duty >= 0; duty -= 5)
        {
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, duty);
            HAL_Delay(5);          /* 约 1s 渐灭 */
        }
    }
}
