const fs = require('fs'), zlib = require('zlib');
const b = fs.readFileSync(process.argv[2]);
const s = b.toString('latin1');
// 抽取所有 stream ... endstream，对 FlateDecode 的做解压
const streams = [];
const re = /stream\r?\n/g;
let m;
while ((m = re.exec(s))) {
  const start = m.index + m[0].length;
  const end = s.indexOf('endstream', start);
  if (end < 0) break;
  let raw = b.slice(start, end);
  // 该 stream 的 dict：找最近的 "obj ... stream"
  const objStart = s.lastIndexOf('obj', m.index);
  const dict = s.slice(objStart, m.index);
  if (/FlateDecode/.test(dict)) {
    try { raw = zlib.inflateSync(raw); } catch (e) { /* 可能非压缩 */ }
  }
  streams.push({ dict, data: raw.toString('latin1') });
}
// 找内容流里的图像绘制：cm 矩阵 + /ImN Do；x-scale 是矩阵第一个数（单位 pt）
let found = 0;
for (const st of streams) {
  const re2 = /([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+cm\s+\/(Image\d+)\s+Do/g;
  let mm;
  while ((mm = re2.exec(st.data))) {
    const wpt = Math.abs(parseFloat(mm[1]));
    const hpt = Math.abs(parseFloat(mm[4]));
    console.log(`${mm[7]}: display ${wpt.toFixed(0)}pt x ${hpt.toFixed(0)}pt  (${(wpt/72*2.54).toFixed(1)}cm wide)`);
    found++;
  }
}
if (!found) console.log('no image Do ops found via simple pattern (streams=' + streams.length + ')');
