$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$dir = 'D:\STM32_LAB3'

# 1) resize tu.png (waveform screenshot) to 600px wide so it fits the PDF page
$tu = Join-Path $dir 'tu.png'
$img = [System.Drawing.Image]::FromFile($tu)
if ($img.Width -gt 600) {
  $nh = [int]([double]$img.Height * 600 / $img.Width)
  $bmp = New-Object System.Drawing.Bitmap(600, $nh)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
  $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
  $g.DrawImage($img, 0, 0, 600, $nh)
  $g.Dispose()
  $bmp.Save((Join-Path $dir 'pdf_tu.png'), [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  Write-Output ("tu.png: {0}x{1} -> 600x{2}" -f $img.Width, $img.Height, $nh)
}
$img.Dispose()

# 2) extract a middle frame from each GIF as a static PNG for the PDF
$pairs = @(@('1.gif','pdf_1.png'), @('2.gif','pdf_2.png'))
foreach ($pair in $pairs) {
  $src = Join-Path $dir $pair[0]
  $dst = Join-Path $dir $pair[1]
  $gif = [System.Drawing.Image]::FromFile($src)
  $dim = New-Object System.Drawing.Imaging.FrameDimension($gif.FrameDimensionsList[0])
  $n = $gif.GetFrameCount($dim)
  $idx = [int]($n / 2)
  $gif.SelectActiveFrame($dim, $idx)
  $fb = New-Object System.Drawing.Bitmap($gif)
  $fb.Save($dst, [System.Drawing.Imaging.ImageFormat]::Png)
  $fb.Dispose()
  $gif.Dispose()
  Write-Output ("{0}: {1} frames, picked #{2} -> {3}" -f $pair[0], $n, $idx, $pair[1])
}
