$ErrorActionPreference = 'Stop'
$dir = 'D:\STM32_LAB3'
$html = Get-ChildItem -Path $dir -Filter 'STM32_PWM*.html' | Select-Object -First 1
if (-not $html) { throw 'HTML not found' }
$pdf = [System.IO.Path]::ChangeExtension($html.FullName, '.pdf')
if (Test-Path $pdf) { Remove-Item $pdf -Force }

$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
try {
  $doc = $word.Documents.Open($html.FullName)
  $doc.SaveAs2($pdf, 17)
  $doc.Close($false)
  Write-Output ("PDF saved: " + $pdf)
} finally {
  $word.Quit()
  [System.Runtime.Interopservices.Marshal]::ReleaseComObject($word) | Out-Null
}
