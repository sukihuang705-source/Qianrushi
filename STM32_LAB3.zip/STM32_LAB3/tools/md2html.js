const fs = require('fs');
const md = fs.readFileSync(process.argv[2], 'utf8');
const lines = md.split(/\r?\n/);
let html = [];
let inCode = false, codeLines = [];
let inTable = false, tableLines = [];
let inList = null; // 'ul' or 'ol'
let inQuote = false;

function esc(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function inline(s) {
  return esc(s)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1">')
    .replace(/`([^`]+)`/g, '<code>$1</code>');
}
function closeTable() {
  if (!inTable) return;
  const [header, , ...rows] = tableLines;
  const cells = l => l.replace(/^\s*\|/,'').replace(/\|\s*$/,'').split('|').map(c => c.trim());
  let out = '<table><thead><tr>' + cells(header).map(c => `<th>${inline(c)}</th>`).join('') + '</tr></thead><tbody>';
  for (const r of rows) {
    if (!r.trim()) continue;
    out += '<tr>' + cells(r).map(c => `<td>${inline(c)}</td>`).join('') + '</tr>';
  }
  out += '</tbody></table>';
  html.push(out); tableLines = []; inTable = false;
}
function closeList() { if (inList) { html.push(`</${inList}>`); inList = null; } }
function closeQuote() { if (inQuote) { html.push('</blockquote>'); inQuote = false; } }

for (const line of lines) {
  if (line.trim().startsWith('```')) {
    closeTable(); closeList(); closeQuote();
    if (!inCode) { inCode = true; codeLines = []; }
    else { html.push('<pre><code>' + codeLines.map(esc).join('\n') + '</code></pre>'); inCode = false; }
    continue;
  }
  if (inCode) { codeLines.push(line); continue; }

  if (line.trim().startsWith('|')) { closeList(); closeQuote(); tableLines.push(line); inTable = true; continue; }
  else if (inTable) closeTable();

  if (/^\s*---+$/.test(line.trim())) { closeList(); closeQuote(); html.push('<hr>'); continue; }

  const img = line.match(/^\s*!\[([^\]]*)\]\(([^)]+)\)\s*$/);
  if (img) { closeTable(); closeList(); closeQuote(); html.push(`<p class="fig"><img src="${esc(img[2])}" alt="${esc(img[1])}"><span class="cap">${inline(img[1])}</span></p>`); continue; }

  const h = line.match(/^(#{1,6})\s+(.*)/);
  if (h) { closeTable(); closeList(); closeQuote(); const n = h[1].length; html.push(`<h${n}>${inline(h[2])}</h${n}>`); continue; }

  if (line.trim().startsWith('>')) { closeTable(); closeList(); if (!inQuote) { html.push('<blockquote>'); inQuote = true; } html.push(`<p>${inline(line.trim().replace(/^>\s?/, ''))}</p>`); continue; }
  else if (inQuote) closeQuote();

  const ul = line.match(/^\s*[-*]\s+(.*)/);
  if (ul) { closeTable(); closeQuote(); if (inList !== 'ul') { closeList(); html.push('<ul>'); inList = 'ul'; } html.push(`<li>${inline(ul[1])}</li>`); continue; }
  const ol = line.match(/^\s*\d+\.\s+(.*)/);
  if (ol) { closeTable(); closeQuote(); if (inList !== 'ol') { closeList(); html.push('<ol>'); inList = 'ol'; } html.push(`<li>${inline(ol[1])}</li>`); continue; }
  closeList();

  if (!line.trim()) { closeQuote(); continue; }
  html.push(`<p>${inline(line)}</p>`);
}
closeTable(); closeList(); closeQuote();

const css = `
body { font-family: "Microsoft YaHei","SimSun",sans-serif; font-size: 11pt; line-height: 1.7; color: #222; margin: 2em; }
h1 { font-size: 20pt; border-bottom: 2px solid #333; padding-bottom: 8px; }
h2 { font-size: 15pt; border-left: 4px solid #2b7bb9; padding-left: 8px; margin-top: 1.4em; }
h3 { font-size: 12.5pt; margin-top: 1.2em; }
code { background: #f4f4f4; padding: 1px 4px; border-radius: 3px; font-family: Consolas, monospace; font-size: 9.5pt; }
pre { background: #f6f8fa; padding: 10px; border-radius: 5px; overflow-x: auto; }
pre code { background: none; padding: 0; }
table { border-collapse: collapse; margin: 1em 0; }
th, td { border: 1px solid #999; padding: 5px 10px; }
th { background: #eef3f8; }
blockquote { border-left: 4px solid #ccc; margin-left: 0; padding-left: 12px; color: #555; }
hr { border: none; border-top: 1px solid #ccc; }
img { max-width: 100%; height: auto; }
p.fig { text-align: center; margin: 1em 0; }
p.fig img { display: block; margin: 0 auto; }
p.fig .cap { display: block; color: #555; font-size: 9.5pt; margin-top: 4px; }
`;

const full = '<!DOCTYPE html><html><head><meta charset="utf-8"><style>' + css + '</style></head><body>' + html.join('\n') + '</body></html>';
fs.writeFileSync(process.argv[3], full, 'utf8');
console.log('HTML written to ' + process.argv[3]);
