const fs = require('fs');
const dir = 'D:/STM32_LAB3/';
const md = fs.readFileSync(dir + 'STM32_PWM_CSDN博客.md', 'utf8')
  .replace('](1.gif)', '](pdf_1.png)')
  .replace('](2.gif)', '](pdf_2.png)')
  .replace('](tu.png)', '](pdf_tu.png)');
fs.writeFileSync(dir + '_pdf.md', md, 'utf8');
console.log('_pdf.md written, images remapped to pdf_*.png');
