## STM32_定时器和PWM

于 2026-10-16 17:19:29 发布

### STM32F103C8T6 定时器 控制 LED：从"定时闪灯"到"呼吸灯"（PWM）

用 STM32F103C8T6（Blue Pill）+ HAL 库，两个小实验带你搞懂通用定时器 TIM2 的两种玩法：定时计数 和 PWM 输出。

一、这篇讲什么

嵌入式课有个实验：用 TIM2~TIM5 某个定时器的通道引脚接一个 LED ，第一步用定时器计数让它 2s 周期亮灭，第二步改成 PWM 模式做呼吸灯，还要用 Keil 的逻辑分析仪看 PWM 波形。

这里我用 TIM2 通道 1（PA0），一路接线两个实验通用。核心代码都贴出来，照着改引脚就能用。

二、先备好环境和接线

板子：STM32F103C8T6 最小系统板（Blue Pill）

工具：Keil MDK + AC6，HAL 库

接线：LED 阳极 → 电阻(330Ω~1kΩ) → PA0，LED 阴极 → GND（高电平点亮）

三、一个前提：我为什么用内部时钟 HSI 8MHz，而不是 72MHz

很多教程都用外部晶振 HSE 配到 72MHz。但 Keil 的软件仿真器模拟不了外部晶振——你切到仿真想看 PWM 波形时，程序会卡在"等 HSE 就绪"那一步，逻辑分析仪啥也看不到。

所以我干脆用内部 HSI 8MHz，真机烧录和软件仿真都能跑，8MHz 做闪灯、做 1kHz PWM 绰绰有余。

1 void SystemClock_Config(void) 2 {

内容来源：csdn.net 3 RCC_OscInitTypeDef RCC_OscInitStruct = {0};

作者昵称：阿司匹林229 4 RCC_ClkInitTypeDef RCC_ClkInitStruct = {0}; 原文链接：https://blog.csdn.net/2503_90536812/article/details/168140761 5 作者主页：https://blog.csdn.net/2503_90536812 6 https://blog.csdn.net/2503_90536812/article/details/168140761?sharetype=blogdetail&sharerId=168140761&sharerefer=PC&sharesource=2503_90536812&spm=1011.2480.3001.8118 1/8

6

RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI; 7

RCC_OscInitStruct.HSIState = RCC_HSI_ON; 8

RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT; 9

RCC_OscInitStruct.PLL.PLLState = RCC_PLL_OFF; /\* 不用 PLL \*/ 10

HAL_RCC_OscConfig(&RCC_OscInitStruct); 11 12

RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | 13

RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2; 14

RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI; 15

RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1; 16

RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1; 17

RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1; 18

HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0); 19

} AI代码解释c运行

四、实验一：定时器计数方式，让 LED 2s 亮灭

思路

定时器最基础的作用就是"定时"。TIM2 从 0 一直加到 ARR 就溢出一次，我把它配成 1 秒溢出一次，每次溢出进中断翻转一下 PA0，LED 就是"亮 1 秒 + 灭 1 秒 = 2 秒一个周期"。

三个寄存器怎么算

定时器时钟 = 8MHz（TIM2 挂 APB1，这里没分频）

PSC = 7999： 8MHz / (7999+1) = 1kHz ，计数器每秒跳 1000 下

ARR = 999： 1kHz / (999+1) = 1Hz ，也就是 1 秒溢出一次

代码内容来源：csdn.net

作者昵称：阿司匹林229 1 TIM_HandleTypeDef htim2; 原文链接：https://blog.csdn.net/2503_90536812/article/details/168140761

作者主页：https://blog.csdn.net/2503_90536812 2 3 https://blog.csdn.net/2503_90536812/article/details/168140761?sharetype=blogdetail&sharerId=168140761&sharerefer=PC&sharesource=2503_90536812&spm=1011.2480.3001.8118 2/8

3

void TIM2_Init(void) 4

{ 5

GPIO_InitTypeDef GPIO_InitStruct = {0}; 6 7

\_\_HAL_RCC_GPIOA_CLK_ENABLE(); 8

\_\_HAL_RCC_TIM2_CLK_ENABLE(); 9 10

GPIO_InitStruct.Pin = GPIO_PIN_0; 11

GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP; /\* 普通输出，靠中断翻转 \*/ 12

GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH; 13

HAL_GPIO_Init(GPIOA, &GPIO_InitStruct); 14 15

htim2.Instance = TIM2; 16

htim2.Init.Prescaler = 7999; 17

htim2.Init.CounterMode = TIM_COUNTERMODE_UP; 18

htim2.Init.Period = 999; 19

htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE; 20

HAL_TIM_Base_Init(&htim2); 21 22

HAL_NVIC_SetPriority(TIM2_IRQn, 2, 0); 23

HAL_NVIC_EnableIRQ(TIM2_IRQn); 24

HAL_TIM_Base_Start_IT(&htim2); /\* 中断方式启动 \*/ 25

} 26 27

/\* 每 1s 调用一次，翻转 LED \*/ 28

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef \*htim) 29

{ 30

if (htim->Instance == TIM2) 31

HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_0); 32

} AI代码解释c运行

内容来源：csdn.net 作者昵称：阿司匹林229 别忘了在 stm32f1xx_it.c 里加中断入口：

原文链接：https://blog.csdn.net/2503_90536812/article/details/168140761 作者主页：https://blog.csdn.net/2503_90536812

https://blog.csdn.net/2503_90536812/article/details/168140761?sharetype=blogdetail&sharerId=168140761&sharerefer=PC&sharesource=2503_90536812&spm=1011.2480.3001.8118 3/8

1 void TIM2_IRQHandler(void) 2 { 3 HAL_TIM_IRQHandler(&htim2); 4 }

AI代码解释c运行

烧录后现象：LED 按 2 秒周期稳定亮-灭（亮 1 秒 + 灭 1 秒）：

五、实验二：PWM 模式做呼吸灯

内容来源：csdn.net 作者昵称：阿司匹林229 PWM 是啥

原文链接：https://blog.csdn.net/2503_90536812/article/details/168140761 作者主页：https://blog.csdn.net/2503_90536812

https://blog.csdn.net/2503_90536812/article/details/168140761?sharetype=blogdetail&sharerId=168140761&sharerefer=PC&sharesource=2503_90536812&spm=1011.2480.3001.8118 4/8

PWM 就是频率固定、占空比 可调的方波。LED 亮度取决于平均电流，平均电流正比于占空比，所以改占空比 = 改亮度。让占空比慢慢从 0 涨到 100% 再降回 0，灯就"呼吸"起来了。

占空比由 CCR（捕获/比较寄存器）决定，公式：

频率 = 8MHz ÷ (PSC+1) ÷ (ARR+1)

占空比 = CCR ÷ (ARR+1)

我这里配成 1kHz：PSC=7、ARR=999。

代码

1 void TIM2_PWM_Init(void) 2 { 3 GPIO_InitTypeDef GPIO_InitStruct = {0}; 4 TIM_OC_InitTypeDef TIM_OC_InitStruct = {0}; 5 6 \_\_HAL_RCC_GPIOA_CLK_ENABLE(); 7 \_\_HAL_RCC_TIM2_CLK_ENABLE(); 8 9 GPIO_InitStruct.Pin = GPIO_PIN_0; 10 GPIO_InitStruct.Mode = GPIO_MODE_AF_PP; /\* 复用推挽，输出 TIM2_CH1 \*/ 11 GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH; 12 HAL_GPIO_Init(GPIOA, &GPIO_InitStruct); 13 14 htim2.Instance = TIM2; 15 htim2.Init.Prescaler = 7; /\* 8MHz/8 = 1MHz \*/ 16 htim2.Init.CounterMode = TIM_COUNTERMODE_UP; 17 htim2.Init.Period = 999; /\* 1MHz/1000 = 1kHz \*/ 18 htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE; 19 HAL_TIM_PWM_Init(&htim2); 20 21 TIM_OC_InitStruct.OCMode = TIM_OCMODE_PWM1; 22 TIM_OC_InitStruct.Pulse = 0;

内容来源：csdn.net 23 TIM_OC_InitStruct.OCPolarity = TIM_OCPOLARITY_HIGH;

作者昵称：阿司匹林229 24 HAL_TIM_PWM_ConfigChannel(&htim2, &TIM_OC_InitStruct, TIM_CHANNEL_1);

原文链接：https://blog.csdn.net/2503_90536812/article/details/168140761 25

作者主页：https://blog.csdn.net/2503_90536812 26 HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1); https://blog.csdn.net/2503_90536812/article/details/168140761?sharetype=blogdetail&sharerId=168140761&sharerefer=PC&sharesource=2503_90536812&spm=1011.2480.3001.8118 5/8

27 } 28 29 int main(void) 30 { 31 int32_t duty = 0; 32 HAL_Init(); 33 SystemClock_Config(); 34 TIM2_PWM_Init(); 35 36 while (1) 37 { 38 for (duty = 0; duty <= 999; duty += 5) /\* 渐亮 \*/ 39 { \_\_HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, duty); HAL_Delay(5); } 40 for (duty = 999; duty >= 0; duty -= 5) /\* 渐灭 \*/ 41 { \_\_HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, duty); HAL_Delay(5); } 42 } 43 }

AI代码解释c运行

想调快调慢就改 HAL_Delay ，想更平滑就减小步长。

烧录后现象：LED 呈呼吸灯效果，由暗渐亮再渐灭，呼吸周期约 2 秒：

内容来源：csdn.net 作者昵称：阿司匹林229 原文链接：https://blog.csdn.net/2503_90536812/article/details/168140761 作者主页：https://blog.csdn.net/2503_90536812

https://blog.csdn.net/2503_90536812/article/details/168140761?sharetype=blogdetail&sharerId=168140761&sharerefer=PC&sharesource=2503_90536812&spm=1011.2480.3001.8118 6/8

六、用 Keil 逻辑分析仪看 PWM 波形

1. Options → Debug，选 Use Simulator；

2. F7 编译，Ctrl+F5 进仿真，F5 运行；

3. 菜单 View → Analysis Windows → Logic Analyzer；

4. Setup 里点新建，信号名填 PORTA.0 （注意不是 GPIOA->ODR ，仿真器只认 PORTA.x 这种老命名），Display Type 选 Bit；

5. 就能看到 1kHz 的 PWM 方波，占空比在缓慢变宽变窄，跟灯的呼吸节奏对上。

抓到的波形如下（占空比由窄 → 宽 → 窄循环变化）：

内容来源：csdn.net 作者昵称：阿司匹林229 原文链接：https://blog.csdn.net/2503_90536812/article/details/168140761 作者主页：https://blog.csdn.net/2503_90536812

https://blog.csdn.net/2503_90536812/article/details/168140761?sharetype=blogdetail&sharerId=168140761&sharerefer=PC&sharesource=2503_90536812&spm=1011.2480.3001.8118 7/8

七、总结

定时器就两个核心用途：计时（中断做动作） 和 产生 PWM。搞懂 PSC、ARR、CCR 三个寄存器，闪灯和呼吸灯就是顺带的事。

标签 \#stm32 #单片机 #嵌入式硬件

内容来源：csdn.net 作者昵称：阿司匹林229 原文链接：https://blog.csdn.net/2503_90536812/article/details/168140761 作者主页：https://blog.csdn.net/2503_90536812

https://blog.csdn.net/2503_90536812/article/details/168140761?sharetype=blogdetail&sharerId=168140761&sharerefer=PC&sharesource=2503_90536812&spm=1011.2480.3001.8118 8/8