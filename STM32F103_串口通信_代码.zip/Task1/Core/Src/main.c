/****************************************************************************
 * 文件名 : main.c
 * 实验   : 嵌入式第二次实验 · 任务一  STM32 USART1 串口通信(轮询方式)
 * 功能   : 1) STM32 通过 USART1(PA9=TX / PA10=RX)向上位机连续发送
 *            "hello windows!",波特率 115200、1 停止位、无校验位。
 *            发送之间可加/不加延时,用来观察上位机是否丢数据。
 *          2) 上位机发一个字符 '#' → STM32 暂停发送;发 '*' → 继续发送。
 * 硬件   : STM32F103C8T6(Blue Pill),USART1 接 USB-TTL 模块(CH340):
 *          PA9(TX) → 模块 RXD,PA10(RX) → 模块 TXD,共地(GND)。
 * 说明   : 本工程用"轮询"方式收字符(非阻塞 HAL_UART_Receive,超时 0),
 *          任务二会改成"中断"方式重做。
 ****************************************************************************/

#include "main.h"      /* 工程头文件(芯片型号、HAL 头) */
#include <string.h>    /* strlen */

/* ==================== 串口句柄(全局,HAL 库靠它管理 USART1) ==================== */
UART_HandleTypeDef huart1;

/* 是否暂停发送:0=发送,1=暂停(收到 '#' 暂停、'*' 恢复) */
volatile uint8_t g_paused = 0;

/* 发送延时开关:
   1 = 每发一句后延时 200ms(正常、稳定,串口助手里一行一行看)
   0 = 不加延时,STM32 用最快速度连续发送(观察是否丢数据/刷屏)
   做任务一(1)实验时,把 1 改成 0 再编译烧录,就能对比两种现象 */
#define USE_SEND_DELAY   1


/****************************************************************************
 * 函数名 : SystemClock_Config
 * 功能   : 配置系统时钟为 72MHz(HSE 8MHz 晶振 + PLL 9 倍频)
 ****************************************************************************/
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
    RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    RCC_OscInitStruct.HSIState       = RCC_HSI_ON;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLMUL     = RCC_PLL_MUL9;
    HAL_RCC_OscConfig(&RCC_OscInitStruct);

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2);
}


/****************************************************************************
 * 函数名 : MX_USART1_UART_Init
 * 功能   : 初始化 USART1:115200、8 数据位、1 停止位、无校验、收发使能
 ****************************************************************************/
void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = 115200;              /* 波特率 115200 */
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;  /* 8 位数据 */
    huart1.Init.StopBits     = UART_STOPBITS_1;     /* 1 位停止位 */
    huart1.Init.Parity       = UART_PARITY_NONE;    /* 无校验位 */
    huart1.Init.Mode         = UART_MODE_TX_RX;     /* 收发都使能 */
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE; /* 不用硬件流控 */
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        /* 初始化失败就死循环,方便调试定位 */
        while (1) {}
    }
}


/****************************************************************************
 * 函数名 : HAL_UART_MspInit
 * 功能   : USART1 的底层初始化(时钟 + 引脚),HAL_UART_Init 会自动调用它
 * 说明   : "Msp" = MCU Support Package,这是 HAL 库约定俗成的底层回调函数,
 *          把"开时钟、配 GPIO"这种和芯片相关的底层活放在这里。
 ****************************************************************************/
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if (huart->Instance == USART1)
    {
        /* 打开 USART1 和 GPIOA 的时钟(USART1 挂在 APB2 总线上) */
        __HAL_RCC_USART1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();

        /* ---- PA9 = TX,复用推挽输出 ---- */
        GPIO_InitStruct.Pin   = GPIO_PIN_9;
        GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;       /* 复用推挽 */
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* ---- PA10 = RX,上拉输入 ---- */
        GPIO_InitStruct.Pin  = GPIO_PIN_10;
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLUP;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
    }
}


/****************************************************************************
 * 主函数
 ****************************************************************************/
int main(void)
{
    uint8_t  ch = 0;
    const char *msg = "hello windows!\r\n";   /* 要发送的内容,末尾回车换行 */

    HAL_Init();              /* 复位外设、初始化 SysTick(HAL_Delay 靠它计时) */
    SystemClock_Config();    /* 72MHz 主频 */
    MX_USART1_UART_Init();   /* USART1 初始化 */

    while (1)
    {
        /* ---------- 接收控制字符:非阻塞轮询,收不到就继续 ---------- */
        if (HAL_UART_Receive(&huart1, &ch, 1, 0) == HAL_OK)
        {
            if (ch == '#')        /* 收到 '#' → 暂停 */
            {
                g_paused = 1;
            }
            else if (ch == '*')   /* 收到 '*' → 继续 */
            {
                g_paused = 0;
            }
        }

        /* ---------- 没暂停就发送一句 ---------- */
        if (g_paused == 0)
        {
            HAL_UART_Transmit(&huart1, (uint8_t *)msg, strlen(msg), 1000);

#if USE_SEND_DELAY
            /* 每句之间延时 200ms,串口助手里能一行一行清楚显示。
               想观察"不加延时"的现象,把上面 #define USE_SEND_DELAY 改成 0 */
            HAL_Delay(200);
#endif
        }
    }
}
