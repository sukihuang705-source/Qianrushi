/****************************************************************************
 * 文件名 : stm32f1xx_it.c
 * 功能   : 中断服务函数(ISR)集中放这里。
 *          本实验(任务一·轮询方式)不需要外设中断,只保留 Cortex-M3 内核
 *          异常的标准处理和 SysTick(供 HAL_Delay 计时)。
 *          任务二(中断方式)会在这里补上 USART1_IRQHandler。
 ****************************************************************************/

#include "main.h"

/****************************************************************************
 * Cortex-M3 内核异常处理(标准模板,一般不用动)
 ****************************************************************************/

void NMI_Handler(void)
{
}

void HardFault_Handler(void)
{
    while (1) {}    /* 硬件错误:死循环,方便调试时定位 */
}

void MemManage_Handler(void)
{
    while (1) {}
}

void BusFault_Handler(void)
{
    while (1) {}
}

void UsageFault_Handler(void)
{
    while (1) {}
}

void SVC_Handler(void)
{
}

void DebugMon_Handler(void)
{
}

void PendSV_Handler(void)
{
}

/* SysTick 中断:HAL 的延时 HAL_Delay 靠它来计时,必须调用 HAL_IncTick() */
void SysTick_Handler(void)
{
    HAL_IncTick();
}
