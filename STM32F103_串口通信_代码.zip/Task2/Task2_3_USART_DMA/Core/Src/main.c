/****************************************************************************
 * 文件名 : main.c
 * 实验   : 嵌入式第二次实验 · 任务二(3)  STM32 串口 DMA 方式连续发送
 * 功能   : 用 DMA(直接存储器访问)方式通过 USART1 向上位机连续发送数据。
 *          CPU 只负责"启动 DMA",之后数据搬运全由 DMA 硬件在后台完成,
 *          不占用 CPU;每发完一次,在"发送完成"中断里自动启动下一次。
 * 波特率 : 115200(可改成 230400/460800 测更高速率)
 * 硬件   : USART1:PA9=TX / PA10=RX,接 USB-TTL 模块。
 * 说明   : USART1 的 TX 发送 DMA 通道是 DMA1_Channel4(芯片固定映射)。
 ****************************************************************************/

#include "main.h"
#include <stdio.h>    /* sprintf */

/* ==================== 句柄与变量 ==================== */
UART_HandleTypeDef huart1;
DMA_HandleTypeDef  hdma_usart1_tx;   /* USART1 发送用的 DMA 句柄 */

uint8_t  tx_buf[64];                 /* 全局发送缓冲(DMA 后台读它,必须全局) */
volatile uint32_t g_tx_count = 0;    /* 已发送次数统计,体现"连续" */


/****************************************************************************
 * 函数名 : SystemClock_Config
 * 功能   : 配置系统时钟为 72MHz
 ****************************************************************************/
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
    RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    RCC_OscInitStruct.HSIState       = RCC_HSI_ON;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLMUL     = RCC_PLL_MUL9;
    HAL_RCC_OscConfig(&RCC_OscInitStruct);

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2);
}


/****************************************************************************
 * 函数名 : MX_USART1_UART_Init
 * 功能   : 初始化 USART1:115200、8 数据位、1 停止位、无校验
 ****************************************************************************/
void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = 115200;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        while (1) {}
    }
}


/****************************************************************************
 * 函数名 : HAL_UART_MspInit
 * 功能   : USART1 底层初始化(时钟 + 引脚 + DMA 发送通道)
 ****************************************************************************/
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if (huart->Instance == USART1)
    {
        /* 时钟:USART1(APB2)、GPIOA、DMA1 */
        __HAL_RCC_USART1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();
        __HAL_RCC_DMA1_CLK_ENABLE();

        /* PA9 = TX,复用推挽输出 */
        GPIO_InitStruct.Pin   = GPIO_PIN_9;
        GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* PA10 = RX,上拉输入 */
        GPIO_InitStruct.Pin  = GPIO_PIN_10;
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLUP;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* ---- 配置 USART1 的发送 DMA 通道(DMA1_Channel4) ---- */
        hdma_usart1_tx.Instance                 = DMA1_Channel4;      /* USART1_TX 固定用 DMA1 通道 4 */
        hdma_usart1_tx.Init.Direction           = DMA_MEMORY_TO_PERIPH; /* 内存 → 外设(发送方向) */
        hdma_usart1_tx.Init.PeriphInc           = DMA_PINC_DISABLE;     /* 外设地址(USART1->DR)不变 */
        hdma_usart1_tx.Init.MemInc              = DMA_MINC_ENABLE;      /* 内存地址自增(逐个字节发) */
        hdma_usart1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;  /* 外设按字节对齐 */
        hdma_usart1_tx.Init.MemDataAlignment    = DMA_MDATAALIGN_BYTE;  /* 内存按字节对齐 */
        hdma_usart1_tx.Init.Mode                = DMA_NORMAL;           /* 普通模式(发完一次停) */
        hdma_usart1_tx.Init.Priority            = DMA_PRIORITY_LOW;
        if (HAL_DMA_Init(&hdma_usart1_tx) != HAL_OK)
        {
            while (1) {}
        }

        /* 把 DMA 句柄挂到串口句柄上,HAL 库才能用 huart->hdmatx */
        __HAL_LINKDMA(huart, hdmatx, hdma_usart1_tx);

        /* 使能 DMA1 通道 4 的传输完成中断(发送完成后进中断 → 回调) */
        HAL_NVIC_SetPriority(DMA1_Channel4_IRQn, 0, 0);
        HAL_NVIC_EnableIRQ(DMA1_Channel4_IRQn);

        /* 使能 USART1 中断(关键!):F1 的 HAL 里 DMA 普通模式发完最后一字节后,
         * 是靠 USART1 的"发送完成 TC 中断"来收尾并回调 TxCpltCallback 的,
         * 只开 DMA 中断不够,这里必须再开 USART1 中断。 */
        HAL_NVIC_SetPriority(USART1_IRQn, 0, 0);
        HAL_NVIC_EnableIRQ(USART1_IRQn);
    }
}


/****************************************************************************
 * 函数名 : HAL_UART_TxCpltCallback
 * 功能   : 串口"发送完成"回调。DMA 把这一句发完后自动进来,
 *          这里把计数 +1 并立刻启动下一句,实现"连续发送"。
 ****************************************************************************/
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        g_tx_count++;
        int len = sprintf((char *)tx_buf, "hello windows! DMA send #%lu\r\n",
                          (unsigned long)g_tx_count);
        HAL_UART_Transmit_DMA(&huart1, tx_buf, len);
    }
}


/****************************************************************************
 * 主函数
 ****************************************************************************/
int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_USART1_UART_Init();

    /* 构造并启动第一句,DMA 开始后台发送 */
    g_tx_count = 1;
    int len = sprintf((char *)tx_buf, "hello windows! DMA send #%lu\r\n",
                      (unsigned long)g_tx_count);
    HAL_UART_Transmit_DMA(&huart1, tx_buf, len);

    while (1)
    {
        /* 主循环啥也不用干,DMA 在后台连续发,发完自动进回调启动下一句 */
    }
}
