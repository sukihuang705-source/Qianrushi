/****************************************************************************
 * 文件名 : stm32f1xx_it.c
 * 功能   : 中断服务函数(ISR)集中放这里。
 *          本实验(任务二·DMA 方式)重点:DMA1_Channel4_IRQHandler ——
 *          USART1 发送 DMA 的传输完成中断。
 ****************************************************************************/

#include "main.h"

/* DMA 句柄、串口句柄定义在 main.c,这里引用它们 */
extern DMA_HandleTypeDef hdma_usart1_tx;
extern UART_HandleTypeDef huart1;

/****************************************************************************
 * Cortex-M3 内核异常处理(标准模板,一般不用动)
 ****************************************************************************/

void NMI_Handler(void)
{
}

void HardFault_Handler(void)
{
    while (1) {}
}

void MemManage_Handler(void)
{
    while (1) {}
}

void BusFault_Handler(void)
{
    while (1) {}
}

void UsageFault_Handler(void)
{
    while (1) {}
}

void SVC_Handler(void)
{
}

void DebugMon_Handler(void)
{
}

void PendSV_Handler(void)
{
}

/* SysTick 中断:HAL_Delay 靠它计时 */
void SysTick_Handler(void)
{
    HAL_IncTick();
}


/****************************************************************************
 * 外设中断处理
 ****************************************************************************/

/* DMA1 通道 4(USART1 发送 DMA)传输完成中断入口。
 * 注意:它清完标志后不是直接回调 TxCpltCallback,而是打开 USART1 的 TC 中断,
 * 最终由下面的 USART1_IRQHandler 收尾后才回调(见 main.c 的 HAL_UART_TxCpltCallback)。 */
void DMA1_Channel4_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&hdma_usart1_tx);
}

/* USART1 中断入口(关键!):F1 的 HAL 里 DMA 普通模式发完最后一字节后,
 * 靠这里的 TC 中断收尾,再由 HAL 回调 HAL_UART_TxCpltCallback 启动下一句。
 * 少了它,发完第一句就卡死不再发。 */
void USART1_IRQHandler(void)
{
    HAL_UART_IRQHandler(&huart1);
}
